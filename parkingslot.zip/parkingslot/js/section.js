window.addEventListener("load", function () {
  const section = document.querySelector("section");
  section.classList.add("visible");
});

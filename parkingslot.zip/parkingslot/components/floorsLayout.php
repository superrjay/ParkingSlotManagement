<div class="slot-overview-header"></div>
                <div class="overview-container">

                <div id="floor-1" class="floor active">
                  <div class="row">
                      <div class="zone-indicator-top">Zone - A</div>
                      <div class="row-section" id="floor1-zone-A">
                          <div class="slot-box row-box" id="floor1-zoneA-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - B</div>
                      <div class="row-section" id="floor1-zone-B">
                          <div class="slot-box row-box" id="floor1-zoneB-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - C</div>
                      <div class="row-section" id="floor1-zone-C">
                          <div class="slot-box row-box" id="floor1-zoneC-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - D</div>
                      <div class="row-section" id="floor1-zone-D">
                          <div class="slot-box row-box" id="floor1-zoneD-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - E</div>
                      <div class="row-section" id="floor1-zone-E">
                          <div class="slot-box row-box" id="floor1-zoneE-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - F</div>
                      <div class="row-section" id="floor1-zone-F">
                          <div class="slot-box row-box" id="floor1-zoneF-slots"></div>
                      </div>
                  </div>
              </div>

              <div id="floor-2" class="floor">
                  <div class="row">
                      <div class="zone-indicator-top">Zone - A</div>
                      <div class="row-section" id="floor2-zone-A">
                          <div class="slot-box row-box" id="floor2-zoneA-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - B</div>
                      <div class="row-section" id="floor2-zone-B">
                          <div class="slot-box row-box" id="floor2-zoneB-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - C</div>
                      <div class="row-section" id="floor2-zone-C">
                          <div class="slot-box row-box" id="floor2-zoneC-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - D</div>
                      <div class="row-section" id="floor2-zone-D">
                          <div class="slot-box row-box" id="floor2-zoneD-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - E</div>
                      <div class="row-section" id="floor2-zone-E">
                          <div class="slot-box row-box" id="floor2-zoneE-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - F</div>
                      <div class="row-section" id="floor2-zone-F">
                          <div class="slot-box row-box" id="floor2-zoneF-slots"></div>
                      </div>
                  </div>
              </div>

              <div id="floor-3" class="floor">
                  <div class="row">
                      <div class="zone-indicator-top">Zone - A</div>
                      <div class="row-section" id="floor3-zone-A">
                          <div class="slot-box row-box" id="floor3-zoneA-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - B</div>
                      <div class="row-section" id="floor3-zone-B">
                          <div class="slot-box row-box" id="floor3-zoneB-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - C</div>
                      <div class="row-section" id="floor3-zone-C">
                          <div class="slot-box row-box" id="floor3-zoneC-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - D</div>
                      <div class="row-section" id="floor3-zone-D">
                          <div class="slot-box row-box" id="floor3-zoneD-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - E</div>
                      <div class="row-section" id="floor3-zone-E">
                          <div class="slot-box row-box" id="floor3-zoneE-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - F</div>
                      <div class="row-section" id="floor3-zone-F">
                          <div class="slot-box row-box" id="floor3-zoneF-slots"></div>
                      </div>
                  </div>
              </div>

              <div id="floor-4" class="floor">
                  <div class="row">
                      <div class="zone-indicator-top">Zone - A</div>
                      <div class="row-section" id="floor4-zone-A">
                          <div class="slot-box row-box" id="floor4-zoneA-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - B</div>
                      <div class="row-section" id="floor4-zone-B">
                          <div class="slot-box row-box" id="floor4-zoneB-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - C</div>
                      <div class="row-section" id="floor4-zone-C">
                          <div class="slot-box row-box" id="floor4-zoneC-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - D</div>
                      <div class="row-section" id="floor4-zone-D">
                          <div class="slot-box row-box" id="floor4-zoneD-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - E</div>
                      <div class="row-section" id="floor4-zone-E">
                          <div class="slot-box row-box" id="floor4-zoneE-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - F</div>
                      <div class="row-section" id="floor4-zone-F">
                          <div class="slot-box row-box" id="floor4-zoneF-slots"></div>
                      </div>
                  </div>
              </div>

              <div id="floor-5" class="floor">
                  <div class="row">
                      <div class="zone-indicator-top">Zone - A</div>
                      <div class="row-section" id="floor5-zone-A">
                          <div class="slot-box row-box" id="floor5-zoneA-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - B</div>
                      <div class="row-section" id="floor5-zone-B">
                          <div class="slot-box row-box" id="floor5-zoneB-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - C</div>
                      <div class="row-section" id="floor5-zone-C">
                          <div class="slot-box row-box" id="floor5-zoneC-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - D</div>
                      <div class="row-section" id="floor5-zone-D">
                          <div class="slot-box row-box" id="floor5-zoneD-slots"></div>
                      </div>
                  </div>

                  <div class="row">
                      <div class="zone-indicator-top">Zone - E</div>
                      <div class="row-section" id="floor5-zone-E">
                          <div class="slot-box row-box" id="floor5-zoneE-slots"></div>
                      </div>
                      <div class="zone-indicator-bottom">Zone - F</div>
                      <div class="row-section" id="floor5-zone-F">
                          <div class="slot-box row-box" id="floor5-zoneF-slots"></div>
                      </div>
                  </div>
              </div>
            </div>

              <div class="overview-footer">
                <div class="pagination">
                  <button class="prev-floor"><i class="fa-solid fa-arrow-left"></i></button>
                  <span class="floor-indicator">Floor 1</span>
                  <button class="next-floor"><i class="fa-solid fa-arrow-right"></i></button>
                </div>
              </div>

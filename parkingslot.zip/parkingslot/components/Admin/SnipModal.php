<div class="snip-overlay">
    <div class="snipModal"></div>
</div>

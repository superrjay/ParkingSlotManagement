
<div class="sidebar">
    <div class="logo">
        <img src="../img/logo.png" alt="">
    </div>

    <div class="links-container">
        <ul class="list">
            <li>
                <a class="links active" href="Dashboard.php">
                    <i class='bx bx-command' ></i>
                    <span class="link-text">Dashboard</span>
                </a>
            </li>
            <li>
                <a class="links" href="SlotManagement.php">
                    <i class='bx bx-car' ></i>
                    <span class="link-text">Slot Management </span>
                </a>
            </li>
            <li>
               <a class="links" href="UserManagement.php">
                    <i class='bx bx-user' ></i>
                    <span class="link-text">User Management</span>
               </a>
            </li>
        </ul>
    </div>

    <div class="footer"></div>
</div>
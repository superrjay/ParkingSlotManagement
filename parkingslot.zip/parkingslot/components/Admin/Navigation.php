<nav class="navbar">
    <div class="nav-contents">
        <div class="navRight">
        <button class="sidebarToggle">
            <svg id="icon" width="24" height="24" viewBox="0 0 24 24">
                <path class="line line1" d="M3 6h18"></path>
                <path class="line line2" d="M3 12h18"></path>
                <path class="line line3" d="M3 18h18"></path>
            </svg>
        </button>
            <h1>Dashboard</h1>
        </div> 
        <div class="user-container">
            <img class="user-image" src="<?php echo htmlspecialchars($Photo); ?>" alt="">
            <span class="indicator"></span>
        </div>
    </div>
</nav>

<svg
    class="animated"
    id="freepik_stories-street-paid-parking"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 750 500"
    version="1.1"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    xmlns:svgjs="http://svgjs.com/svgjs"
>
    <g
        id="freepik--background-complete--inject-7"
        class="animable"
        style="transform-origin: 374.82px 178.628px"
    >
        <path
            d="M222.31,294.62S351,287.46,420.93,269.83C479,255.2,532,226.69,558,226.69c56.78,0,159.64,67.93,159.64,67.93H343"
            style="
                fill: rgb(219, 219, 219);
                transform-origin: 469.975px 260.655px;
            "
            id="elqls8ns161mr"
            class="animable"
        ></path>
        <path
            d="M32,294.62S147.2,254.44,181.1,254.44c25.14,0,219.44,40.18,219.44,40.18Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 216.27px 274.53px;
            "
            id="elepvi00i1a1o"
            class="animable"
        ></path>
        <path
            d="M566.47,100.15c7.19,0,128.17.79,135.77.55.55,0,.84-.82.3-1.09-4.8-2.37-10.23-1.89-15.21-3.57-2.93-1-4.73-2.91-6.77-5.1a14,14,0,0,0-6.29-4.11,13.31,13.31,0,0,0-6.86-.22c-2.45.59-4.58,2-6.93,2.88-5.81,2.19-11.45.11-15.6-4.19-3.43-3.55-6.79-6.89-11.44-8.8a15.21,15.21,0,0,0-12.12-.17c-4.44,2-7.49,6-11.65,8.49-4.95,2.88-10.85,2.2-16.31,3.07s-9.65,5.47-14.44,8.12a10.19,10.19,0,0,1-5.21,1.61,28.62,28.62,0,0,1-3.18-.45c-1.65-.2-3.21-.15-4.32,1.22C565.94,98.73,566,100.15,566.47,100.15Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 634.438px 87.9497px;
            "
            id="elf1xm3x0wbo"
            class="animable"
        ></path>
        <path
            d="M52.78,80.89c5.25,0,93.57.58,99.13.4.39,0,.61-.59.21-.79-3.5-1.73-7.47-1.39-11.1-2.61-2.14-.72-3.46-2.12-4.94-3.73a10.28,10.28,0,0,0-4.6-3,9.74,9.74,0,0,0-5-.15c-1.79.42-3.35,1.45-5.06,2.1-4.24,1.6-8.37.08-11.4-3.06-2.49-2.59-5-5-8.35-6.43a11.08,11.08,0,0,0-8.85-.12c-3.24,1.47-5.46,4.42-8.5,6.2-3.61,2.1-7.92,1.61-11.91,2.24s-7,4-10.54,5.93a7.49,7.49,0,0,1-3.81,1.18c-.78,0-1.54-.24-2.32-.33-1.2-.15-2.34-.12-3.15.89C52.39,79.85,52.43,80.89,52.78,80.89Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 102.401px 71.9808px;
            "
            id="eldq50rvpkq15"
            class="animable"
        ></path>
        <path
            d="M425.22,157.81c5.25,0,93.58.58,99.13.41a.43.43,0,0,0,.21-.8c-3.49-1.73-7.46-1.38-11.1-2.61-2.14-.72-3.45-2.12-4.94-3.72a10.2,10.2,0,0,0-4.6-3,9.64,9.64,0,0,0-5-.16,42.82,42.82,0,0,0-5.06,2.1c-4.24,1.6-8.36.08-11.39-3.06-2.5-2.59-5-5-8.36-6.42a11.09,11.09,0,0,0-8.84-.13c-3.24,1.47-5.47,4.42-8.51,6.2-3.61,2.11-7.92,1.61-11.91,2.24s-7,4-10.53,5.93a7.55,7.55,0,0,1-3.81,1.18,22.72,22.72,0,0,1-2.32-.33,3.18,3.18,0,0,0-3.16.89C424.84,156.78,424.88,157.81,425.22,157.81Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 474.844px 148.908px;
            "
            id="elgfjszfob85g"
            class="animable"
        ></path>
        <path
            d="M265.69,118.3c5.25,0,93.57.58,99.12.4.4,0,.62-.6.22-.8-3.5-1.73-7.47-1.38-11.1-2.61-2.14-.72-3.46-2.12-4.94-3.72a10.2,10.2,0,0,0-4.6-3,9.64,9.64,0,0,0-5-.16c-1.79.43-3.35,1.46-5.06,2.1-4.24,1.6-8.37.08-11.4-3.06-2.5-2.59-4.95-5-8.35-6.42a11.08,11.08,0,0,0-8.85-.12c-3.24,1.46-5.46,4.42-8.5,6.19-3.61,2.11-7.93,1.61-11.91,2.25s-7,4-10.54,5.92a7.39,7.39,0,0,1-3.81,1.18,23.13,23.13,0,0,1-2.32-.33c-1.2-.14-2.34-.11-3.15.89C265.3,117.26,265.34,118.3,265.69,118.3Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 315.311px 109.391px;
            "
            id="eljgs8oihkibe"
            class="animable"
        ></path>
        <path
            d="M138.73,139.43c.11.29,139.22,0,137.46,0-.8,0,1.22-1.2.44-1.59-4.53-2.24-9.49-2.31-14.42-2.76a22.21,22.21,0,0,1-8.42-2c-2.62-1.38-4.26-3.76-6.12-6a26.11,26.11,0,0,0-23.75-9c-9.89,1.55-17.69,9.08-27.6,10.47-5.95.83-11.58-1.47-17.4-2.28a21.18,21.18,0,0,0-13.06,2.39c-3.14,1.55-6,2.86-9.59,3.11-2.72.19-5.46-.12-8.19-.15a18.32,18.32,0,0,0-12,4.81C135.59,136.83,134.19,139.43,138.73,139.43Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 206.15px 128.681px;
            "
            id="el23n1ybmzig3"
            class="animable"
        ></path>
        <path
            d="M477,194.82c.1.29,139.21,0,137.46,0-.8,0,1.21-1.2.43-1.59-4.53-2.24-9.48-2.3-14.42-2.76a22.26,22.26,0,0,1-8.42-2c-2.62-1.38-4.25-3.76-6.12-6a26.1,26.1,0,0,0-23.75-9c-9.89,1.55-17.69,9.08-27.6,10.47-6,.83-11.58-1.47-17.4-2.28a21.18,21.18,0,0,0-13.06,2.39c-3.14,1.55-6,2.86-9.59,3.11-2.72.19-5.45-.12-8.18-.15a18.34,18.34,0,0,0-12.05,4.81C473.87,192.22,472.46,194.82,477,194.82Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 544.413px 184.071px;
            "
            id="elc690kf3sf8"
            class="animable"
        ></path>
        <polygon
            points="45.77 196.93 45.77 294.62 243.02 294.62 243.02 215.01 225.91 215.01 225.91 235.8 221.51 235.8 221.51 199.48 199.75 199.48 199.75 233.95 196.87 233.95 196.87 190.23 177.96 190.23 177.96 202.23 168.26 202.23 168.26 217.16 165.32 217.16 165.32 207.77 148.13 207.77 148.13 235.79 143.1 235.79 143.1 213.01 127.38 213.01 127.38 195.71 116.69 195.71 116.69 185.86 104.32 185.86 104.32 229.56 100.16 229.56 100.16 211.32 79.78 211.32 79.78 237.43 76.97 237.43 76.97 216.12 56.31 216.12 56.31 196.93 45.77 196.93"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 144.395px 240.24px;
            "
            id="el3mmusy0d89x"
            class="animable"
        ></polygon>
        <g id="elwh5m4cuef8m">
            <rect
                x="238.03"
                y="217.63"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 239.48px 219.615px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ellzoypv3b1he">
            <rect
                x="233.01"
                y="217.63"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 234.46px 219.615px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elq3quelgnou">
            <rect
                x="227.99"
                y="217.63"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 229.44px 219.615px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eli07ug4q0a2">
            <rect
                x="238.03"
                y="223.61"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 239.48px 225.595px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eloej2orc5h2i">
            <rect
                x="233.01"
                y="223.61"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 234.46px 225.595px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el4mteng9v37l">
            <rect
                x="227.99"
                y="223.61"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 229.44px 225.595px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7n8f9hkkyf8">
            <rect
                x="238.03"
                y="229.59"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 239.48px 231.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eltyeaoctraqh">
            <rect
                x="233.01"
                y="229.59"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 234.46px 231.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elnhujgc9jqkb">
            <rect
                x="227.99"
                y="229.59"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 229.44px 231.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elxqengfpy4b">
            <rect
                x="238.03"
                y="235.56"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 239.48px 237.545px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elixfk12td3cm">
            <rect
                x="233.01"
                y="235.56"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 234.46px 237.545px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elwwi6q3xwsic">
            <rect
                x="227.99"
                y="235.56"
                width="2.9"
                height="3.97"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 229.44px 237.545px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmfu9fjlx92o">
            <rect
                x="137.79"
                y="215.85"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 139.24px 217.505px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elwmhlhwlmcf7">
            <rect
                x="132.77"
                y="215.85"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 134.22px 217.505px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el94ludlwcrj">
            <rect
                x="127.75"
                y="215.85"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 129.2px 217.505px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eljy6otqjsmz8">
            <rect
                x="137.79"
                y="220.84"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 139.24px 222.495px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbdwp3irteoq">
            <rect
                x="132.77"
                y="220.84"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 134.22px 222.495px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ell3zvkfad47">
            <rect
                x="127.75"
                y="220.84"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 129.2px 222.495px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el938r1muvo4r">
            <rect
                x="137.79"
                y="225.83"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 139.24px 227.485px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elm7bugl9a9l">
            <rect
                x="132.77"
                y="225.83"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 134.22px 227.485px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el36p0m19v4xw">
            <rect
                x="127.75"
                y="225.83"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 129.2px 227.485px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el0a8bnum7o0cf">
            <rect
                x="137.79"
                y="230.81"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 139.24px 232.465px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elic38znneb2o">
            <rect
                x="132.77"
                y="230.81"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 134.22px 232.465px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7o94y8hqdyi">
            <rect
                x="127.75"
                y="230.81"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 129.2px 232.465px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elccfotl9zifa">
            <rect
                x="137.79"
                y="235.92"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 139.24px 237.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elpxugzzemv6j">
            <rect
                x="132.77"
                y="235.92"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 134.22px 237.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elylsk14oqaep">
            <rect
                x="127.75"
                y="235.92"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 129.2px 237.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elslxfdo5grse">
            <rect
                x="137.79"
                y="241.04"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 139.24px 242.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elz9hot2laabo">
            <rect
                x="132.77"
                y="241.04"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 134.22px 242.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elpqs0sxbixye">
            <rect
                x="127.75"
                y="241.04"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 129.2px 242.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elreerrxc7ux">
            <rect
                x="137.79"
                y="246.15"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 139.24px 247.805px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eluxquxhs2y7">
            <rect
                x="132.77"
                y="246.15"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 134.22px 247.805px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el82c20kwy8kp">
            <rect
                x="127.75"
                y="246.15"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 129.2px 247.805px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eldntw0weim4b">
            <rect
                x="137.79"
                y="251.26"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 139.24px 252.915px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el65hfu9brfpa">
            <rect
                x="132.77"
                y="251.26"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 134.22px 252.915px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elc4c10vrg4c">
            <rect
                x="127.75"
                y="251.26"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 129.2px 252.915px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elkv0qyyem6m">
            <rect
                x="202.37"
                y="202.02"
                width="16.67"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 210.705px 203.26px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elsawxzhpdkql">
            <rect
                x="202.37"
                y="206.85"
                width="16.67"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 210.705px 208.09px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el6wgyhc58m98">
            <rect
                x="202.37"
                y="211.67"
                width="16.67"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 210.705px 212.91px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elx800fyxtpe">
            <rect
                x="202.37"
                y="216.49"
                width="16.67"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 210.705px 217.73px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el5fs2z21ks7m">
            <rect
                x="202.37"
                y="221.31"
                width="16.67"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 210.705px 222.55px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7tlomgmjmxm">
            <rect
                x="202.37"
                y="226.13"
                width="16.67"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 210.705px 227.37px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eln4w2i5m8j3">
            <rect
                x="202.37"
                y="230.95"
                width="16.67"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 210.705px 232.19px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elwt3z9f8r5ik">
            <rect
                x="202.37"
                y="235.77"
                width="16.67"
                height="2.49"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 210.705px 237.015px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elcyrv3zo3pj">
            <rect
                x="82.37"
                y="213.64"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 214.88px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eldqnkf0ebqb">
            <rect
                x="82.37"
                y="218.46"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 219.7px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el8s07imyskkb">
            <rect
                x="82.37"
                y="223.28"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 224.52px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eldtf1qknz6u">
            <rect
                x="82.37"
                y="228.1"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 229.34px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elty60p02vcrn">
            <rect
                x="82.37"
                y="232.93"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 234.17px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el09flxkoeyvqu">
            <rect
                x="82.37"
                y="237.75"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 238.99px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eljs1ga2924dj">
            <rect
                x="82.37"
                y="242.57"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 243.81px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elxtc0b44ru3">
            <rect
                x="82.37"
                y="247.39"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 248.63px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el66qoussb5kf">
            <rect
                x="82.37"
                y="251.97"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 253.21px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eltigbfcbw7s">
            <rect
                x="82.37"
                y="256.55"
                width="15.32"
                height="2.49"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 257.795px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elw3fccc971p">
            <rect
                x="82.37"
                y="261.13"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 262.37px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ell2zurr70vpe">
            <rect
                x="82.37"
                y="265.72"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 266.96px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eloln9cjim0q8">
            <rect
                x="82.37"
                y="270.3"
                width="15.32"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 90.03px 271.54px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el4ab56rhus2">
            <rect
                x="57.59"
                y="219.46"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 220.7px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elvs7769m1bkl">
            <rect
                x="57.59"
                y="224.29"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 225.53px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el9i7mrr45eiv">
            <rect
                x="57.59"
                y="229.11"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 230.35px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eliw3vri704i">
            <rect
                x="57.59"
                y="233.93"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 235.17px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmc1trwe6f2d">
            <rect
                x="57.59"
                y="238.75"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 239.99px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbojmky5wdgf">
            <rect
                x="57.59"
                y="243.57"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 244.81px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elrldv2eslx5">
            <rect
                x="57.59"
                y="248.39"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 249.63px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1a39amtp2o9">
            <rect
                x="57.59"
                y="253.21"
                width="16.19"
                height="2.49"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 254.455px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elsppilomytva">
            <rect
                x="57.59"
                y="257.53"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 258.77px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3wsayr4uzou">
            <rect
                x="57.59"
                y="261.85"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 263.09px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eltu77e3tg3g">
            <rect
                x="57.59"
                y="266.16"
                width="16.19"
                height="2.48"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 65.685px 267.4px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3yt9x3s8e7">
            <rect
                x="155.15"
                y="210.02"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 157.725px 211.22px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbi9dnmwkm6s">
            <rect
                x="155.15"
                y="214.68"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 157.725px 215.88px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbwgn45bopjc">
            <rect
                x="155.15"
                y="219.33"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 157.725px 220.53px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elcmdx28owzon">
            <rect
                x="155.15"
                y="223.99"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 157.725px 225.19px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7y2vm2t3me">
            <rect
                x="155.15"
                y="228.65"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 157.725px 229.85px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el72z9z5bj132">
            <rect
                x="155.15"
                y="233.3"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 157.725px 234.5px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elk60fjbp4wx">
            <rect
                x="155.15"
                y="237.96"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 157.725px 239.16px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elzszcsls7jr">
            <rect
                x="155.15"
                y="242.61"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 157.725px 243.81px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eljb6a5f4bz69">
            <rect
                x="148.14"
                y="210.02"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 150.715px 211.22px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="els2czlzp45ks">
            <rect
                x="148.14"
                y="214.68"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 150.715px 215.88px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el15nbj70ze9t">
            <rect
                x="148.14"
                y="219.33"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 150.715px 220.53px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el9wolhcbjbsv">
            <rect
                x="148.14"
                y="223.99"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 150.715px 225.19px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elo1g9fmj76d">
            <rect
                x="148.14"
                y="228.65"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 150.715px 229.85px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eloo8ttqza6g">
            <rect
                x="148.14"
                y="233.3"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 150.715px 234.5px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elyn7uvutbxrc">
            <rect
                x="148.14"
                y="237.96"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 150.715px 239.16px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elzck82ebzjb">
            <rect
                x="148.14"
                y="242.61"
                width="5.15"
                height="2.4"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 150.715px 243.81px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmh3nlnf2m3">
            <rect
                x="188.64"
                y="192.75"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 194.64px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elqp2nzyspfy">
            <rect
                x="180.64"
                y="192.75"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 194.64px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el2knbgor8bku">
            <rect
                x="188.64"
                y="198.31"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 200.2px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elw3psswtg7fj">
            <rect
                x="180.64"
                y="198.31"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 200.2px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eln194erplp3n">
            <rect
                x="188.64"
                y="203.86"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 205.75px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el2ktmjrhz0uy">
            <rect
                x="180.64"
                y="203.86"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 205.75px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el10zienemlgq">
            <rect
                x="188.64"
                y="209.42"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 211.31px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elnsrxx5oqe7l">
            <rect
                x="180.64"
                y="209.42"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 211.31px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eltephucygqcg">
            <rect
                x="188.64"
                y="214.98"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 216.87px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eln5wf3wll44c">
            <rect
                x="180.64"
                y="214.98"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 216.87px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ellld932t0dth">
            <rect
                x="188.64"
                y="220.54"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 222.43px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el53vlss2nmrh">
            <rect
                x="180.64"
                y="220.54"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 222.43px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eltexlranhhw">
            <rect
                x="188.64"
                y="226.1"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 227.99px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elzf7j7yfr8j">
            <rect
                x="180.64"
                y="226.1"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 227.99px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elhs8gikj0qn4">
            <rect
                x="188.64"
                y="231.66"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 233.55px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el85o10f6bhi3">
            <rect
                x="180.64"
                y="231.66"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 233.55px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elq1szewukt19">
            <rect
                x="170.73"
                y="203.86"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 205.75px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elfuua06qhknj">
            <rect
                x="170.73"
                y="209.42"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 211.31px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elk2csccbaoe">
            <rect
                x="170.73"
                y="214.98"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 216.87px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elv2ab22y9vib">
            <rect
                x="170.73"
                y="220.54"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 222.43px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elw4fo4x169yn">
            <rect
                x="170.73"
                y="226.1"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 227.99px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elggv1v4jp31l">
            <rect
                x="170.73"
                y="231.66"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 233.55px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elsapqu4eo3jk">
            <rect
                x="188.64"
                y="237.15"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 239.04px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eleiidtg0dgqh">
            <rect
                x="180.64"
                y="237.15"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 239.04px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmbvnow3pht">
            <rect
                x="170.73"
                y="237.15"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 239.04px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elgknknn7oe16">
            <rect
                x="188.64"
                y="242.65"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 244.54px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elxjytq311fza">
            <rect
                x="180.64"
                y="242.65"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 244.54px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el5i1t1jdlpa2">
            <rect
                x="170.73"
                y="242.65"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 244.54px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elao1ovgzar14">
            <rect
                x="188.64"
                y="248.14"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 250.03px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1d3o940vwnd">
            <rect
                x="180.64"
                y="248.14"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 250.03px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmw6zbmt94b">
            <rect
                x="170.73"
                y="248.14"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 250.03px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elkmdv0dlklu">
            <rect
                x="188.64"
                y="253.63"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 255.52px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elyt8yv6ce54f">
            <rect
                x="180.64"
                y="253.63"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 255.52px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elwuwy0dhsq9r">
            <rect
                x="170.73"
                y="253.63"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 255.52px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elk1vf3f1tm8">
            <rect
                x="188.64"
                y="259.13"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 191.32px 261.02px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el52jjhaq7ubj">
            <rect
                x="180.64"
                y="259.13"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 183.32px 261.02px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elodrv9ul9mbq">
            <rect
                x="170.73"
                y="259.13"
                width="5.36"
                height="3.78"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 173.41px 261.02px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elu53zm0qn79s">
            <rect
                x="122.3"
                y="198.15"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 199.805px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elg2zqxrhkvdg">
            <rect
                x="117.28"
                y="198.15"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 199.805px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eltxcd9s93xmp">
            <rect
                x="122.3"
                y="203.13"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 204.785px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3yt93kbjs4k">
            <rect
                x="117.28"
                y="203.13"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 204.785px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1l75yn8bc51">
            <rect
                x="122.3"
                y="208.12"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 209.775px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elifvfx2daaj">
            <rect
                x="117.28"
                y="208.12"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 209.775px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el5y8c9wsq89m">
            <rect
                x="122.3"
                y="213.11"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 214.765px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1bejm7kk4zk">
            <rect
                x="117.28"
                y="213.11"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 214.765px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el63xlotmu8y">
            <rect
                x="122.3"
                y="218.22"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 219.875px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eln2nypncqxih">
            <rect
                x="117.28"
                y="218.22"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 219.875px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el17hsolcto4d">
            <rect
                x="122.3"
                y="223.33"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 224.985px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elaxlowz55qwl">
            <rect
                x="117.28"
                y="223.33"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 224.985px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elad76q5d72ft">
            <rect
                x="122.3"
                y="228.44"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 230.095px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elexk7nkrhck">
            <rect
                x="117.28"
                y="228.44"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 230.095px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eltt5v9dsqhcj">
            <rect
                x="122.3"
                y="233.55"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 235.205px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eldmzdupxe4jb">
            <rect
                x="117.28"
                y="233.55"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 235.205px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elsn16s8phmsc">
            <rect
                x="122.3"
                y="238.72"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 240.375px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elnrscj3pvye">
            <rect
                x="117.28"
                y="238.72"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 240.375px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elitw9a3n1jub">
            <rect
                x="122.3"
                y="243.88"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 245.535px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elg9u2empg7qr">
            <rect
                x="117.28"
                y="243.88"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 245.535px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ela94pbfsh03">
            <rect
                x="122.3"
                y="249.05"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 250.705px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eliplxdrejxxq">
            <rect
                x="117.28"
                y="249.05"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 250.705px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3asu84iej3j">
            <rect
                x="122.3"
                y="254.22"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 123.75px 255.875px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3x4d6sa8uyi">
            <rect
                x="117.28"
                y="254.22"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 118.73px 255.875px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eljt6g6a28apa">
            <rect
                x="51.6"
                y="198.69"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 200.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elqs1peoedz0a">
            <rect
                x="46.58"
                y="198.69"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 200.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3gqgymrl6n">
            <rect
                x="51.6"
                y="204.56"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 206.515px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elibaij94u95l">
            <rect
                x="46.58"
                y="204.56"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 206.515px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elx7yo9kr7ad">
            <rect
                x="51.6"
                y="210.44"
                width="2.9"
                height="3.9"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 212.39px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elw7b8iae57dm">
            <rect
                x="46.58"
                y="210.44"
                width="2.9"
                height="3.9"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 212.39px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elz5ctzupulu">
            <rect
                x="51.6"
                y="216.31"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 218.265px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el0rmmek0ivfgf">
            <rect
                x="46.58"
                y="216.31"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 218.265px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elvj6pr8vevta">
            <rect
                x="51.6"
                y="222.34"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 224.295px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elvmdot2025vn">
            <rect
                x="46.58"
                y="222.34"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 224.295px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ely8r5cb0yj6q">
            <rect
                x="51.6"
                y="228.36"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 230.315px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elu735zcl71b">
            <rect
                x="46.58"
                y="228.36"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 230.315px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elvavfkuhgjvn">
            <rect
                x="51.6"
                y="234.38"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 236.335px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elcipe9t02mg">
            <rect
                x="46.58"
                y="234.38"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 236.335px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elwte3yl30rfs">
            <rect
                x="51.6"
                y="240.4"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 242.355px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elxsyyqc59r8b">
            <rect
                x="46.58"
                y="240.4"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 242.355px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el44doht6rr1r">
            <rect
                x="51.6"
                y="246.48"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 248.435px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmfz3j2a07uf">
            <rect
                x="46.58"
                y="246.48"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 248.435px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elzmy8tqkzg4">
            <rect
                x="51.6"
                y="252.57"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 254.525px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elijmhv1aprio">
            <rect
                x="46.58"
                y="252.57"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 254.525px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elzpk31epum99">
            <rect
                x="51.6"
                y="258.66"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 260.615px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ellfews0c7lt">
            <rect
                x="46.58"
                y="258.66"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 260.615px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1ie2si6b3eb">
            <rect
                x="51.6"
                y="264.74"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 53.05px 266.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el6nvv70zux6h">
            <rect
                x="46.58"
                y="264.74"
                width="2.9"
                height="3.91"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 48.03px 266.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elp8cuadx1pzi">
            <rect
                x="111.57"
                y="198.15"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 199.805px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1jjs6sonj4f">
            <rect
                x="106.55"
                y="198.15"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 199.805px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el0zt6n2w4yr2e">
            <rect
                x="111.57"
                y="193.03"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 194.685px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el6yw5duj4ta7">
            <rect
                x="106.55"
                y="193.03"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 194.685px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmfoec5hv62">
            <rect
                x="111.57"
                y="187.92"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 189.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elrini5fvq8z">
            <rect
                x="106.55"
                y="187.92"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 189.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1f047xgk4cl">
            <rect
                x="111.57"
                y="203.13"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 204.785px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el26br1p8e6p1">
            <rect
                x="106.55"
                y="203.13"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 204.785px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elzx9ezqcz0h">
            <rect
                x="111.57"
                y="208.12"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 209.775px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7aelx31lpkh">
            <rect
                x="106.55"
                y="208.12"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 209.775px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el2y6irz1arjr">
            <rect
                x="111.57"
                y="213.11"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 214.765px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elw9xm6m1unvf">
            <rect
                x="106.55"
                y="213.11"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 214.765px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elwbyutknk5q">
            <rect
                x="111.57"
                y="218.22"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 219.875px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el6ti03b7c9db">
            <rect
                x="106.55"
                y="218.22"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 219.875px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1px7hf2nrgk">
            <rect
                x="111.57"
                y="223.33"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 224.985px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elhiw0n0wz8b5">
            <rect
                x="106.55"
                y="223.33"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 224.985px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el0ce505wh9gro">
            <rect
                x="111.57"
                y="228.44"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 230.095px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3gau69zowg6">
            <rect
                x="106.55"
                y="228.44"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 230.095px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elrt20uhby03">
            <rect
                x="111.57"
                y="233.55"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 235.205px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el8qn73o7uzyb">
            <rect
                x="106.55"
                y="233.55"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 235.205px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elh83piup73p">
            <rect
                x="111.57"
                y="238.72"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 240.375px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elagk0mtdj81">
            <rect
                x="106.55"
                y="238.72"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 240.375px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elkmcon7h25dr">
            <rect
                x="111.57"
                y="243.88"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 245.535px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elooffc1si11q">
            <rect
                x="106.55"
                y="243.88"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 245.535px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elwqst1vkxg0k">
            <rect
                x="111.57"
                y="249.05"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 250.705px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el2ltbzxtkzs9">
            <rect
                x="106.55"
                y="249.05"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 250.705px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ela9z1xvq89e">
            <rect
                x="111.57"
                y="254.22"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 113.02px 255.875px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eldfj9lm13z4">
            <rect
                x="106.55"
                y="254.22"
                width="2.9"
                height="3.31"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 108px 255.875px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <polygon
            points="243.03 294.62 424.57 294.62 424.57 182.4 402.83 182.4 402.83 208.81 397.23 208.81 397.23 193.86 369.58 193.86 369.58 217.53 365.92 217.53 365.92 161.98 341.89 161.98 341.89 177.22 329.57 177.22 329.57 196.2 325.84 196.2 325.84 184.26 303.99 184.26 303.99 219.87 297.61 219.87 297.61 190.93 277.62 190.93 277.62 168.94 264.04 168.94 248.32 169.01 248.32 211.95 243.03 211.95 243.03 294.62"
            style="fill: rgb(235, 235, 235); transform-origin: 333.8px 228.3px"
            id="el7glrgd8piyw"
            class="animable"
        ></polygon>
        <g id="el19zlwg8btyg">
            <rect
                x="418.23"
                y="185.72"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 420.07px 188.245px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elfvihnokkgrs">
            <rect
                x="411.85"
                y="185.72"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 413.69px 188.245px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eldjnefjrhal8">
            <rect
                x="405.47"
                y="185.72"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 407.31px 188.245px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1abhq51hfwq">
            <rect
                x="418.23"
                y="193.32"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 420.07px 195.845px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elah296uz0cju">
            <rect
                x="411.85"
                y="193.32"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 413.69px 195.845px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eludge1ts1tfa">
            <rect
                x="405.47"
                y="193.32"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 407.31px 195.845px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elp9mm9k6izge">
            <rect
                x="418.23"
                y="200.91"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 420.07px 203.435px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elkom2tcyvf1">
            <rect
                x="411.85"
                y="200.91"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 413.69px 203.435px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbrjnlkfb8y6">
            <rect
                x="405.47"
                y="200.91"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 407.31px 203.435px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elqlzu86nttd">
            <rect
                x="418.23"
                y="208.51"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 420.07px 211.035px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eld59qbzvdqku">
            <rect
                x="411.85"
                y="208.51"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 413.69px 211.035px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elhyr73sph3mr">
            <rect
                x="405.47"
                y="208.51"
                width="3.68"
                height="5.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 407.31px 211.035px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="els8x8ukdu7ks">
            <rect
                x="290.86"
                y="194.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 292.7px 196.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el45zxsg1y5py">
            <rect
                x="284.48"
                y="194.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 286.32px 196.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1pgklw5roor">
            <rect
                x="278.1"
                y="194.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 279.94px 196.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elsepwb51uyes">
            <rect
                x="290.86"
                y="200.87"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 292.7px 202.975px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elkiw0iv77xt">
            <rect
                x="284.48"
                y="200.87"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 286.32px 202.975px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elx02udy1qe8q">
            <rect
                x="278.1"
                y="200.87"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 279.94px 202.975px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elj7vyjj6abma">
            <rect
                x="290.86"
                y="207.21"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 292.7px 209.315px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elxvs53r9uydk">
            <rect
                x="284.48"
                y="207.21"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 286.32px 209.315px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el6reiugo5kqe">
            <rect
                x="278.1"
                y="207.21"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 279.94px 209.315px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elded5t8nrxf">
            <rect
                x="290.86"
                y="213.54"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 292.7px 215.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elj8ku55dcq2">
            <rect
                x="284.48"
                y="213.54"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 286.32px 215.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elzmtw6lar3ud">
            <rect
                x="278.1"
                y="213.54"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 279.94px 215.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el357yrysoztl">
            <rect
                x="290.86"
                y="220.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 292.7px 222.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmbe6fobv3h8">
            <rect
                x="284.48"
                y="220.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 286.32px 222.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7tc76v2bw47">
            <rect
                x="278.1"
                y="220.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 279.94px 222.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3xmkykm8n9u">
            <rect
                x="290.86"
                y="226.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 292.7px 228.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el83a1l5weyj6">
            <rect
                x="284.48"
                y="226.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 286.32px 228.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elr5vvkwfvko">
            <rect
                x="278.1"
                y="226.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 279.94px 228.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elkc01guv5wf">
            <rect
                x="290.86"
                y="233.03"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 292.7px 235.135px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el9k2td2ogzfw">
            <rect
                x="284.48"
                y="233.03"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 286.32px 235.135px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elqt1hppn2s5">
            <rect
                x="278.1"
                y="233.03"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 279.94px 235.135px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eleyisovnsw2n">
            <rect
                x="290.86"
                y="239.52"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 292.7px 241.625px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ellpazpu31meo">
            <rect
                x="284.48"
                y="239.52"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 286.32px 241.625px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elke9nrykkt1">
            <rect
                x="278.1"
                y="239.52"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 279.94px 241.625px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elfz2af0xm50p">
            <rect
                x="372.91"
                y="197.09"
                width="21.18"
                height="3.16"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 383.5px 198.67px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eluadku1uqgon">
            <rect
                x="372.91"
                y="203.22"
                width="21.18"
                height="3.16"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 383.5px 204.8px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elpmw9u4tniyn">
            <rect
                x="372.91"
                y="209.35"
                width="21.18"
                height="3.16"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 383.5px 210.93px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elhl2h72v6q9l">
            <rect
                x="372.91"
                y="215.47"
                width="21.18"
                height="3.16"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 383.5px 217.05px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elg403cnfw4d">
            <rect
                x="372.91"
                y="221.6"
                width="21.18"
                height="3.16"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 383.5px 223.18px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elk5ew9b48yys">
            <rect
                x="372.91"
                y="227.73"
                width="21.18"
                height="3.16"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 383.5px 229.31px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elzcbje47ku4">
            <rect
                x="372.91"
                y="233.85"
                width="21.18"
                height="3.16"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 383.5px 235.43px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ely5muwbiw6f">
            <rect
                x="372.91"
                y="239.98"
                width="21.18"
                height="3.16"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 383.5px 241.56px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elnnhdd1nnny">
            <rect
                x="312.91"
                y="187.12"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 316.18px 188.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elnan8vdylu6">
            <rect
                x="312.91"
                y="193.04"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 316.18px 194.565px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elu1b5r0eou8">
            <rect
                x="312.91"
                y="198.96"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 316.18px 200.485px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elgsjwp4n7ul5">
            <rect
                x="312.91"
                y="204.87"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 316.18px 206.395px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el2rvv55wpeah">
            <rect
                x="312.91"
                y="210.79"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 316.18px 212.315px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmsiixaieech">
            <rect
                x="312.91"
                y="216.7"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 316.18px 218.225px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elh2oc8vb4pf4">
            <rect
                x="312.91"
                y="222.62"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 316.18px 224.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el9bvuowsqirg">
            <rect
                x="312.91"
                y="228.54"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 316.18px 230.065px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eloszasxujhcg">
            <rect
                x="304.01"
                y="187.12"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 307.28px 188.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eliodmq7bjsz9">
            <rect
                x="304.01"
                y="193.04"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 307.28px 194.565px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elhqdnlfsg66n">
            <rect
                x="304.01"
                y="198.96"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 307.28px 200.485px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elgnff409hxef">
            <rect
                x="304.01"
                y="204.87"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 307.28px 206.395px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elvg3w7bi66c">
            <rect
                x="304.01"
                y="210.79"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 307.28px 212.315px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elksec00942ym">
            <rect
                x="304.01"
                y="216.7"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 307.28px 218.225px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elrw28dgjkei">
            <rect
                x="304.01"
                y="222.62"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 307.28px 224.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el5roaglwbbdk">
            <rect
                x="304.01"
                y="228.54"
                width="6.54"
                height="3.05"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 307.28px 230.065px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7aioi4pwqt">
            <rect
                x="355.46"
                y="165.17"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 167.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ela99jtve6t8n">
            <rect
                x="345.3"
                y="165.17"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 167.575px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elc40sdphqo9">
            <rect
                x="355.46"
                y="172.24"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 174.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elw9apaq1tpm">
            <rect
                x="345.3"
                y="172.24"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 174.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elvwb5dpbimi">
            <rect
                x="355.46"
                y="179.3"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 181.705px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el0nbaoih1ah8h">
            <rect
                x="345.3"
                y="179.3"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 181.705px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elsz0h8et2a3q">
            <rect
                x="355.46"
                y="186.36"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 188.765px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ele9ppnbxthv">
            <rect
                x="345.3"
                y="186.36"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 188.765px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el5729y4bv3ap">
            <rect
                x="355.46"
                y="193.43"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 195.835px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el5v8humz5rce">
            <rect
                x="345.3"
                y="193.43"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 195.835px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elfdeelg5htpw">
            <rect
                x="355.46"
                y="200.49"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 202.895px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ely76meemsig9">
            <rect
                x="345.3"
                y="200.49"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 202.895px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elxi49pefwix">
            <rect
                x="355.46"
                y="207.56"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 209.965px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elcx6emaiww6g">
            <rect
                x="345.3"
                y="207.56"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 209.965px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eli177zw74iu">
            <rect
                x="355.46"
                y="214.62"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 217.025px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elpt4g7lhemki">
            <rect
                x="345.3"
                y="214.62"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 217.025px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el83xojhuokg3">
            <rect
                x="332.71"
                y="179.3"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 181.705px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ellmeettti3d8">
            <rect
                x="332.71"
                y="186.36"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 188.765px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elyymxnkyhs5o">
            <rect
                x="332.71"
                y="193.43"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 195.835px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7lqn79oxh06">
            <rect
                x="332.71"
                y="200.49"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 202.895px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elijdsskhnfw">
            <rect
                x="332.71"
                y="207.56"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 209.965px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elao3qgc7kdc">
            <rect
                x="332.71"
                y="214.62"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 217.025px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el759k8xziw1t">
            <rect
                x="355.46"
                y="221.6"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 224.005px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elncsx77ukj7">
            <rect
                x="345.3"
                y="221.6"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 224.005px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eluwzpjxmsn8e">
            <rect
                x="332.71"
                y="221.6"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 224.005px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elvr8mfe8eqf">
            <rect
                x="355.46"
                y="228.58"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 230.985px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elnv9apu01xzg">
            <rect
                x="345.3"
                y="228.58"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 230.985px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elz27jqv2apmj">
            <rect
                x="332.71"
                y="228.58"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 230.985px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elhu2qrz7e6np">
            <rect
                x="355.46"
                y="235.56"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 237.965px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1nh41o2fovsj">
            <rect
                x="345.3"
                y="235.56"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 237.965px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eljaf997v8b9">
            <rect
                x="332.71"
                y="235.56"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 237.965px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elg4cb38hslwr">
            <rect
                x="355.46"
                y="242.54"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 244.945px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eljavumeohzj">
            <rect
                x="345.3"
                y="242.54"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 244.945px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1vaicseibdah">
            <rect
                x="332.71"
                y="242.54"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 244.945px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el0tj9o9gavgo">
            <rect
                x="355.46"
                y="249.52"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 358.865px 251.925px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbvuzos3a5kc">
            <rect
                x="345.3"
                y="249.52"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 348.705px 251.925px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elhgc5w7johm4">
            <rect
                x="332.71"
                y="249.52"
                width="6.81"
                height="4.81"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 336.115px 251.925px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elcf01okovpx">
            <rect
                x="271.17"
                y="172.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 174.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elk2fnc4gqz7b">
            <rect
                x="264.79"
                y="172.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 174.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elgt0zwuei5f">
            <rect
                x="271.17"
                y="178.37"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 180.475px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7itfz15hi24">
            <rect
                x="264.79"
                y="178.37"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 180.475px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elxbswzeddfye">
            <rect
                x="271.17"
                y="184.71"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 186.815px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el4ytf6ezomhx">
            <rect
                x="264.79"
                y="184.71"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 186.815px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el7j4yiwmbkhf">
            <rect
                x="271.17"
                y="191.05"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 193.155px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elrwmdnaisdy">
            <rect
                x="264.79"
                y="191.05"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 193.155px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elkkmi2hffr4f">
            <rect
                x="271.17"
                y="197.54"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 199.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elwzwcc0jp6yk">
            <rect
                x="264.79"
                y="197.54"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 199.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el6sdr9z5055">
            <rect
                x="271.17"
                y="204.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 206.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elglopl91chxp">
            <rect
                x="264.79"
                y="204.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 206.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ellgylu0cpj9f">
            <rect
                x="271.17"
                y="210.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 212.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbztjr1zlklk">
            <rect
                x="264.79"
                y="210.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 212.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elii4ir7r4k5">
            <rect
                x="271.17"
                y="217.03"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 219.135px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elgoulszes3wn">
            <rect
                x="264.79"
                y="217.03"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 219.135px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elrucslxv1n6">
            <rect
                x="271.17"
                y="223.59"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 225.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elnshidd20slm">
            <rect
                x="264.79"
                y="223.59"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 225.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elrjiwh6awu8">
            <rect
                x="271.17"
                y="230.15"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 232.255px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="ely8wmhs72tci">
            <rect
                x="264.79"
                y="230.15"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 232.255px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elotzhv5gxm1i">
            <rect
                x="271.17"
                y="236.72"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 238.825px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eldcuvb13dcth">
            <rect
                x="264.79"
                y="236.72"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 238.825px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elmq8li6tbhbi">
            <rect
                x="271.17"
                y="243.28"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 273.01px 245.385px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el5k6p6qhadv">
            <rect
                x="264.79"
                y="243.28"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 266.63px 245.385px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el3ah8hwikozs">
            <rect
                x="257.53"
                y="172.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 174.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el2p0fmsnz249">
            <rect
                x="251.16"
                y="172.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 174.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eljk56z9nl6c">
            <rect
                x="257.53"
                y="178.37"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 180.475px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elc370hwmwjee">
            <rect
                x="251.16"
                y="178.37"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 180.475px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elc3j4c2dc4f">
            <rect
                x="257.53"
                y="184.71"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 186.815px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1xdmtnwf39i">
            <rect
                x="251.16"
                y="184.71"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 186.815px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elenxsjkhkfqh">
            <rect
                x="257.53"
                y="191.05"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 193.155px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el6j52kk63cke">
            <rect
                x="251.16"
                y="191.05"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 193.155px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elevgtcf1nnco">
            <rect
                x="257.53"
                y="197.54"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 199.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el29axpninyaz">
            <rect
                x="251.16"
                y="197.54"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 199.645px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elinb32ft67wh">
            <rect
                x="257.53"
                y="204.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 206.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elyqwbjtjt7od">
            <rect
                x="251.16"
                y="204.04"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 206.145px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eln4o1pbaffr">
            <rect
                x="257.53"
                y="210.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 212.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elu40lubp264b">
            <rect
                x="251.16"
                y="210.53"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 212.635px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el1bojsled7m9">
            <rect
                x="257.53"
                y="217.03"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 219.135px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el08atpgxvuzre">
            <rect
                x="251.16"
                y="217.03"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 219.135px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elr1wd4rvgv1h">
            <rect
                x="257.53"
                y="223.59"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 225.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elrp19zywd9ci">
            <rect
                x="251.16"
                y="223.59"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 225.695px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elfn2cxl5kezb">
            <rect
                x="257.53"
                y="230.15"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 232.255px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el51k63j56we3">
            <rect
                x="251.16"
                y="230.15"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 232.255px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbkdb1k9rzl4">
            <rect
                x="257.53"
                y="236.72"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 238.825px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elbaagwveehzv">
            <rect
                x="251.16"
                y="236.72"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 238.825px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elfj52zw3dvl">
            <rect
                x="257.53"
                y="243.28"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 259.37px 245.385px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="elcds6ajqm4yk">
            <rect
                x="251.16"
                y="243.28"
                width="3.68"
                height="4.21"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 253px 245.385px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
    </g>
    <g
        id="freepik--Trees--inject-7"
        class="animable"
        style="transform-origin: 529.421px 249.99px"
    >
        <path
            d="M520.47,283.94c-.77.78-9.81,1.12-13.09,1.12s-12.32-.34-13.09-1.12,10.16-60.81,13.09-60.81S521.25,283.17,520.47,283.94Z"
            style="fill: rgb(69, 90, 100); transform-origin: 507.38px 254.095px"
            id="elwo0ekz2ztfr"
            class="animable"
        ></path>
        <path
            d="M520.65,268.64c-2.23.86-10.5,4.22-12.28,5.2,0-.37,0-.75,0-1.12,2-1.18,4-2.34,6-3.5a72.11,72.11,0,0,0,6.45-3.84c.1-.07,0-.27-.09-.21a53.09,53.09,0,0,0-6.31,3.48c-2,1.19-4,2.42-6,3.66l0-8.63a68.89,68.89,0,0,0,9.42-4.79c.1-.06,0-.25-.09-.2a70.33,70.33,0,0,0-9.34,4.6c0-1.49,0-3,0-4.49-.08-7.7-.1-15.41-.29-23.11,2-1,4-1.87,5.93-2.86.13-.07,0-.29-.09-.24-2,.78-3.91,1.7-5.86,2.56q-.15-6-.5-11.92a.1.1,0,0,0-.2,0c-.28,7.38-.26,14.77-.16,22.15-2-1.62-4.2-3-6.27-4.62-.08-.06-.15.07-.07.13,2.16,1.64,4.18,3.47,6.34,5.11,0,.41,0,.83,0,1.25-2.2-1-4.44-1.95-6.66-2.9-.17-.07-.33.18-.15.26,2.26,1.09,4.52,2.2,6.82,3.22.05,3.66.11,7.32.16,11,.08,6.39.22,12.78.36,19.16-4.15-2.1-8.35-4.15-12.56-6.13-.16-.07-.3.15-.14.24a131.26,131.26,0,0,0,12.71,6.39c.11,5.3.22,10.61.29,15.92,0,.32.51.32.5,0-.07-6.77-.08-13.54-.1-20.31A125,125,0,0,0,520.81,269C521,268.91,520.87,268.56,520.65,268.64Z"
            style="fill: rgb(55, 71, 79); transform-origin: 507.951px 258.89px"
            id="el72d0ic5i1z4"
            class="animable"
        ></path>
        <path
            d="M492.55,282.22c-.9.9-11.4,1.3-15.21,1.3s-14.31-.4-15.21-1.3,11.8-70.66,15.21-70.66S493.45,281.31,492.55,282.22Z"
            style="fill: rgb(69, 90, 100); transform-origin: 477.34px 247.54px"
            id="elozpq80mfn7b"
            class="animable"
        ></path>
        <path
            d="M492.76,264.44c-2.59,1-12.2,4.9-14.27,6,0-.44,0-.87,0-1.31l7-4.06a84,84,0,0,0,7.49-4.46c.12-.08.05-.32-.1-.25a62.39,62.39,0,0,0-7.34,4.05c-2.36,1.38-4.69,2.81-7,4.25,0-3.34,0-6.69,0-10a79.15,79.15,0,0,0,10.94-5.56c.12-.07,0-.29-.1-.24a80.9,80.9,0,0,0-10.85,5.35l0-5.21c-.1-8.95-.12-17.91-.34-26.86,2.27-1.15,4.62-2.17,6.89-3.32.15-.08.05-.34-.11-.27-2.31.9-4.54,2-6.8,3-.13-4.62-.3-9.23-.58-13.84a.12.12,0,1,0-.24,0c-.32,8.57-.29,17.15-.19,25.73-2.36-1.88-4.87-3.55-7.27-5.37-.1-.07-.19.08-.09.15,2.51,1.91,4.85,4,7.37,5.94,0,.48,0,1,0,1.45-2.56-1.17-5.15-2.26-7.74-3.37-.2-.08-.38.21-.18.31,2.64,1.26,5.26,2.55,7.93,3.74q.09,6.38.19,12.75c.1,7.42.26,14.84.42,22.26q-7.24-3.66-14.6-7.13c-.18-.09-.35.18-.16.28a151,151,0,0,0,14.77,7.42c.13,6.17.26,12.33.34,18.5a.29.29,0,0,0,.58,0c-.09-7.87-.1-15.73-.12-23.59,2.54-.63,12.16-4.75,14.45-5.88C493.17,264.75,493,264.34,492.76,264.44Z"
            style="fill: rgb(55, 71, 79); transform-origin: 478.018px 253.123px"
            id="elf9mv05374r8"
            class="animable"
        ></path>
        <path
            d="M572.63,281.28c-1,1-12.26,1.4-16.36,1.4s-15.39-.43-16.36-1.4,12.7-76,16.36-76S573.6,280.31,572.63,281.28Z"
            style="fill: rgb(55, 71, 79); transform-origin: 556.27px 243.98px"
            id="elqse5yisu2z"
            class="animable"
        ></path>
        <path
            d="M572.85,262.17c-2.78,1.06-13.11,5.26-15.34,6.49,0-.47,0-.94,0-1.41,2.49-1.47,5-2.92,7.49-4.37a88.15,88.15,0,0,0,8.06-4.79c.12-.09.06-.34-.11-.27a66.63,66.63,0,0,0-7.89,4.36c-2.54,1.48-5,3-7.55,4.57,0-3.6,0-7.19,0-10.79a85,85,0,0,0,11.77-6c.13-.08,0-.32-.1-.25a85.92,85.92,0,0,0-11.67,5.75c0-1.87,0-3.74,0-5.61-.1-9.62-.12-19.26-.37-28.89,2.45-1.23,5-2.32,7.42-3.56.16-.08,0-.36-.12-.3-2.49,1-4.88,2.12-7.32,3.19-.13-5-.32-9.93-.62-14.89a.13.13,0,0,0-.26,0c-.34,9.22-.31,18.45-.2,27.68-2.53-2-5.24-3.82-7.82-5.78-.1-.08-.2.09-.1.17,2.7,2,5.22,4.33,7.93,6.38,0,.52,0,1,0,1.56-2.75-1.26-5.54-2.43-8.32-3.62-.22-.09-.41.22-.19.33,2.83,1.36,5.65,2.74,8.52,4,.07,4.57.15,9.14.2,13.71.11,8,.28,16,.45,23.94q-7.78-3.94-15.69-7.66a.18.18,0,0,0-.18.3,164.92,164.92,0,0,0,15.89,8c.14,6.63.28,13.26.36,19.89a.32.32,0,0,0,.63,0c-.1-8.46-.11-16.92-.13-25.37,2.74-.68,13.08-5.11,15.54-6.32C573.3,262.5,573.12,262.06,572.85,262.17Z"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 556.991px 249.917px;
            "
            id="el06zdklf7sceu"
            class="animable"
        ></path>
        <path
            d="M630,281.28c-1,1-12.26,1.4-16.36,1.4s-15.39-.43-16.36-1.4,12.7-76,16.36-76S631,280.31,630,281.28Z"
            style="fill: rgb(55, 71, 79); transform-origin: 613.641px 243.98px"
            id="elv4guao680b"
            class="animable"
        ></path>
        <path
            d="M630.23,262.17c-2.78,1.06-13.11,5.26-15.34,6.49,0-.47,0-.94,0-1.41,2.49-1.47,5-2.92,7.49-4.37a88.15,88.15,0,0,0,8.06-4.79c.12-.09.06-.34-.11-.27a66.63,66.63,0,0,0-7.89,4.36c-2.54,1.48-5,3-7.55,4.57,0-3.6,0-7.19,0-10.79a85,85,0,0,0,11.77-6c.13-.08,0-.32-.1-.25a85.92,85.92,0,0,0-11.67,5.75c0-1.87,0-3.74,0-5.61-.1-9.62-.12-19.26-.37-28.89,2.45-1.23,5-2.32,7.42-3.56.16-.08,0-.36-.12-.3-2.49,1-4.88,2.12-7.32,3.19-.13-5-.32-9.93-.62-14.89a.13.13,0,0,0-.26,0c-.34,9.22-.31,18.45-.2,27.68-2.53-2-5.24-3.82-7.82-5.78-.1-.08-.2.09-.1.17,2.7,2,5.22,4.33,7.93,6.38,0,.52,0,1,0,1.56-2.75-1.26-5.54-2.43-8.32-3.62-.22-.09-.41.22-.19.33,2.83,1.36,5.65,2.74,8.52,4,.07,4.57.15,9.14.2,13.71.11,8,.28,16,.45,23.94q-7.78-3.94-15.69-7.66a.18.18,0,0,0-.18.3,164.92,164.92,0,0,0,15.89,8c.14,6.63.28,13.26.36,19.89a.32.32,0,0,0,.63,0c-.1-8.46-.11-16.92-.13-25.37,2.74-.68,13.08-5.11,15.54-6.32C630.68,262.5,630.5,262.06,630.23,262.17Z"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 614.371px 249.917px;
            "
            id="elecus8wg6qnt"
            class="animable"
        ></path>
        <path
            d="M504.5,285.24c-.68.68-8.61,1-11.5,1s-10.81-.31-11.49-1,8.92-53.4,11.49-53.4S505.18,284.56,504.5,285.24Z"
            style="fill: rgb(55, 71, 79); transform-origin: 493.005px 259.04px"
            id="elbb0gq4yx3vp"
            class="animable"
        ></path>
        <path
            d="M504.66,271.81c-2,.75-9.22,3.7-10.79,4.56v-1l5.26-3.07a60.89,60.89,0,0,0,5.67-3.37c.08-.06,0-.24-.08-.19a46.72,46.72,0,0,0-5.54,3.07c-1.79,1-3.55,2.12-5.31,3.21,0-2.53,0-5,0-7.58a60.18,60.18,0,0,0,8.28-4.21c.09-.05,0-.22-.08-.17a60.54,60.54,0,0,0-8.2,4c0-1.31,0-2.63,0-3.94-.07-6.77-.08-13.54-.25-20.3,1.72-.87,3.49-1.64,5.21-2.51.11-.06,0-.26-.09-.21-1.74.68-3.42,1.49-5.14,2.24-.09-3.49-.22-7-.44-10.46a.09.09,0,1,0-.18,0c-.24,6.48-.22,13-.14,19.45-1.78-1.42-3.68-2.68-5.5-4.06-.07,0-.13.06-.07.12,1.9,1.44,3.68,3,5.58,4.48,0,.37,0,.73,0,1.1-1.93-.89-3.89-1.71-5.85-2.54-.15-.07-.28.15-.13.22,2,1,4,1.93,6,2.83.05,3.21.1,6.43.14,9.64.08,5.61.2,11.22.32,16.82q-5.47-2.76-11-5.38a.12.12,0,0,0-.12.21,116.37,116.37,0,0,0,11.16,5.61q.15,7,.25,14c0,.28.45.28.44,0-.06-6-.07-11.89-.09-17.83a108.7,108.7,0,0,0,10.93-4.45C505,272.05,504.85,271.74,504.66,271.81Z"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 493.541px 263.189px;
            "
            id="elisnif8x8dzt"
            class="animable"
        ></path>
        <path
            d="M451.3,285.24c-.69.68-8.62,1-11.5,1s-10.82-.31-11.5-1,8.93-53.4,11.5-53.4S452,284.56,451.3,285.24Z"
            style="fill: rgb(55, 71, 79); transform-origin: 439.801px 259.04px"
            id="ele7pjbggbhqh"
            class="animable"
        ></path>
        <path
            d="M451.45,271.81c-1.95.75-9.21,3.7-10.78,4.56,0-.33,0-.66,0-1q2.63-1.54,5.27-3.07a60.73,60.73,0,0,0,5.66-3.37c.09-.06,0-.24-.08-.19a48.36,48.36,0,0,0-5.54,3.07c-1.78,1-3.55,2.12-5.31,3.21,0-2.53,0-5,0-7.58a60.06,60.06,0,0,0,8.27-4.21c.09-.05,0-.22-.07-.17a60.54,60.54,0,0,0-8.2,4l0-3.94c-.07-6.77-.09-13.54-.26-20.3,1.72-.87,3.5-1.64,5.22-2.51.11-.06,0-.26-.09-.21-1.75.68-3.43,1.49-5.14,2.24-.1-3.49-.23-7-.44-10.46a.09.09,0,1,0-.18,0c-.24,6.48-.22,13-.14,19.45-1.78-1.42-3.69-2.68-5.5-4.06-.07,0-.14.06-.07.12,1.9,1.44,3.67,3,5.58,4.48,0,.37,0,.73,0,1.1-1.93-.89-3.9-1.71-5.85-2.54-.15-.07-.29.15-.13.22,2,1,4,1.93,6,2.83,0,3.21.1,6.43.14,9.64.07,5.61.2,11.22.32,16.82-3.65-1.84-7.34-3.64-11-5.38a.12.12,0,0,0-.12.21,116.37,116.37,0,0,0,11.16,5.61c.1,4.66.2,9.32.26,14a.22.22,0,0,0,.44,0c-.07-6-.08-11.89-.09-17.83a109.5,109.5,0,0,0,10.92-4.45C451.77,272.05,451.64,271.74,451.45,271.81Z"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 440.334px 263.195px;
            "
            id="el1aqy46hswzt"
            class="animable"
        ></path>
        <path
            d="M524.51,285.3c.67.67,8.56,1,11.43,1s10.76-.3,11.43-1-8.87-53.1-11.43-53.1S523.83,284.62,524.51,285.3Z"
            style="fill: rgb(69, 90, 100); transform-origin: 535.94px 259.25px"
            id="el0jmul609htsc"
            class="animable"
        ></path>
        <path
            d="M524.35,271.94c1.95.74,9.17,3.68,10.73,4.54v-1l-5.24-3.05a63.73,63.73,0,0,1-5.63-3.35c-.09-.06,0-.24.08-.19A45.58,45.58,0,0,1,529.8,272c1.78,1,3.53,2.11,5.28,3.19l0-7.54a59.31,59.31,0,0,1-8.22-4.18c-.09-.05,0-.22.07-.18a61.14,61.14,0,0,1,8.16,4c0-1.3,0-2.61,0-3.91.07-6.73.09-13.47.26-20.19-1.71-.87-3.47-1.63-5.19-2.5-.11,0,0-.25.09-.2,1.74.68,3.41,1.48,5.11,2.23.1-3.47.23-6.94.44-10.41a.09.09,0,0,1,.18,0c.24,6.45.22,12.9.14,19.35,1.77-1.42,3.66-2.67,5.47-4,.07-.05.13.07.06.12-1.88,1.44-3.65,3-5.54,4.46,0,.36,0,.73,0,1.09,1.92-.88,3.87-1.69,5.81-2.53.16-.06.29.16.14.23-2,1-4,1.92-6,2.81,0,3.2-.1,6.39-.14,9.59-.07,5.57-.2,11.15-.32,16.73q5.45-2.76,11-5.36c.14-.07.26.13.13.21a115.13,115.13,0,0,1-11.1,5.58c-.1,4.63-.2,9.26-.26,13.9a.22.22,0,0,1-.44,0c.07-5.91.08-11.82.09-17.73a110.68,110.68,0,0,1-10.86-4.42C524,272.17,524.16,271.87,524.35,271.94Z"
            style="fill: rgb(55, 71, 79); transform-origin: 535.44px 263.465px"
            id="elv9yhesczb9l"
            class="animable"
        ></path>
        <path
            d="M581.8,285.3c.68.67,8.56,1,11.43,1s10.76-.3,11.43-1-8.87-53.1-11.43-53.1S581.12,284.62,581.8,285.3Z"
            style="fill: rgb(69, 90, 100); transform-origin: 593.23px 259.25px"
            id="elapu2wf9x1d"
            class="animable"
        ></path>
        <path
            d="M581.64,271.94c2,.74,9.17,3.68,10.73,4.54v-1l-5.23-3.05a62.48,62.48,0,0,1-5.64-3.35c-.08-.06,0-.24.08-.19a44.83,44.83,0,0,1,5.51,3.05c1.78,1,3.53,2.11,5.28,3.19,0-2.51,0-5,0-7.54a59.43,59.43,0,0,1-8.23-4.18c-.09-.05,0-.22.07-.18a61.14,61.14,0,0,1,8.16,4c0-1.3,0-2.61,0-3.91.07-6.73.08-13.47.25-20.19-1.71-.87-3.47-1.63-5.18-2.5-.11,0,0-.25.08-.2,1.74.68,3.41,1.48,5.12,2.23.09-3.47.22-6.94.43-10.41,0-.11.18-.11.18,0,.24,6.45.22,12.9.14,19.35,1.77-1.42,3.66-2.67,5.47-4,.07-.05.14.07.07.12-1.89,1.44-3.65,3-5.55,4.46,0,.36,0,.73,0,1.09,1.92-.88,3.87-1.69,5.82-2.53.15-.06.28.16.13.23-2,1-3.95,1.92-6,2.81,0,3.2-.1,6.39-.14,9.59-.07,5.57-.19,11.15-.31,16.73q5.44-2.76,11-5.36c.14-.07.27.13.13.21a115.13,115.13,0,0,1-11.1,5.58c-.1,4.63-.2,9.26-.26,13.9a.22.22,0,0,1-.43,0c.06-5.91.07-11.82.09-17.73a108.7,108.7,0,0,1-10.86-4.42C581.33,272.17,581.45,271.87,581.64,271.94Z"
            style="fill: rgb(55, 71, 79); transform-origin: 592.736px 263.385px"
            id="elfx3ypiv1wxv"
            class="animable"
        ></path>
    </g>
    <g
        id="freepik--Floor--inject-7"
        class="animable"
        style="transform-origin: 375px 377.63px"
    >
        <rect
            x="33.68"
            y="453.37"
            width="682.63"
            height="7.27"
            style="
                fill: rgb(199, 199, 199);
                transform-origin: 374.995px 457.005px;
            "
            id="elx1hmogspmx"
            class="animable"
        ></rect>
        <path
            d="M81.54,453.37a7.86,7.86,0,0,1,.81,3.64,7.73,7.73,0,0,1-.81,3.63,7.73,7.73,0,0,1-.81-3.63A7.86,7.86,0,0,1,81.54,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 81.54px 457.005px"
            id="el24k9twquw2k"
            class="animable"
        ></path>
        <path
            d="M134.9,453.37a8.56,8.56,0,0,1,0,7.27,7.61,7.61,0,0,1-.81-3.63A7.74,7.74,0,0,1,134.9,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 134.899px 457.005px"
            id="elclt8hwbpqr"
            class="animable"
        ></path>
        <path
            d="M188.25,453.37a7.74,7.74,0,0,1,.81,3.64,7.61,7.61,0,0,1-.81,3.63,8.56,8.56,0,0,1,0-7.27Z"
            style="fill: rgb(38, 50, 56); transform-origin: 188.251px 457.005px"
            id="el8383xm90kcv"
            class="animable"
        ></path>
        <path
            d="M241.61,453.37a7.86,7.86,0,0,1,.81,3.64,7.73,7.73,0,0,1-.81,3.63,7.73,7.73,0,0,1-.81-3.63A7.86,7.86,0,0,1,241.61,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 241.61px 457.005px"
            id="ely9cj42y9grk"
            class="animable"
        ></path>
        <path
            d="M295,453.37a8.56,8.56,0,0,1,0,7.27,7.74,7.74,0,0,1-.82-3.63A7.88,7.88,0,0,1,295,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 294.994px 457.005px"
            id="elrlmxfsbgpl"
            class="animable"
        ></path>
        <path
            d="M348.32,453.37a7.74,7.74,0,0,1,.81,3.64,7.61,7.61,0,0,1-.81,3.63,7.73,7.73,0,0,1-.81-3.63A7.86,7.86,0,0,1,348.32,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 348.32px 457.005px"
            id="elx9dcsw3y12"
            class="animable"
        ></path>
        <path
            d="M401.68,453.37a7.86,7.86,0,0,1,.81,3.64,7.73,7.73,0,0,1-.81,3.63,7.61,7.61,0,0,1-.81-3.63A7.74,7.74,0,0,1,401.68,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 401.68px 457.005px"
            id="eluxsm21h5eem"
            class="animable"
        ></path>
        <path
            d="M455,453.37a7.88,7.88,0,0,1,.82,3.64,7.74,7.74,0,0,1-.82,3.63,8.56,8.56,0,0,1,0-7.27Z"
            style="fill: rgb(38, 50, 56); transform-origin: 455.006px 457.005px"
            id="el6xk1dvhsjzo"
            class="animable"
        ></path>
        <path
            d="M508.39,453.37a7.86,7.86,0,0,1,.81,3.64,7.73,7.73,0,0,1-.81,3.63,7.73,7.73,0,0,1-.81-3.63A7.86,7.86,0,0,1,508.39,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 508.39px 457.005px"
            id="elwd2xn3kqp4"
            class="animable"
        ></path>
        <path
            d="M561.75,453.37a8.56,8.56,0,0,1,0,7.27,7.61,7.61,0,0,1-.81-3.63A7.74,7.74,0,0,1,561.75,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 561.749px 457.005px"
            id="el3ip3yicr0ug"
            class="animable"
        ></path>
        <path
            d="M615.1,453.37a7.74,7.74,0,0,1,.81,3.64,7.61,7.61,0,0,1-.81,3.63,8.56,8.56,0,0,1,0-7.27Z"
            style="fill: rgb(38, 50, 56); transform-origin: 615.101px 457.005px"
            id="elq4i47rj5u8c"
            class="animable"
        ></path>
        <path
            d="M668.46,453.37a7.86,7.86,0,0,1,.81,3.64,7.73,7.73,0,0,1-.81,3.63,7.73,7.73,0,0,1-.81-3.63A7.86,7.86,0,0,1,668.46,453.37Z"
            style="fill: rgb(38, 50, 56); transform-origin: 668.46px 457.005px"
            id="elv3bouhs4qni"
            class="animable"
        ></path>
        <path
            d="M33.19,460.64c219-.61,464.63-.62,683.62,0-219,.62-464.63.61-683.62,0Z"
            style="fill: rgb(38, 50, 56); transform-origin: 375px 460.64px"
            id="ela84p53ejze7"
            class="animable"
        ></path>
        <path
            d="M33.19,294.62c219-.61,464.63-.62,683.62,0-219,.62-464.63.61-683.62,0Z"
            style="fill: rgb(38, 50, 56); transform-origin: 375px 294.62px"
            id="elvic2s5y8bbf"
            class="animable"
        ></path>
    </g>
    <g
        id="freepik--parking-machine--inject-7"
        class="animable"
        style="transform-origin: 642.545px 282.105px"
    >
        <g id="eltivhbtv4sf8">
            <rect
                x="590.59"
                y="231.35"
                width="89.84"
                height="222.8"
                style="
                    fill: rgb(55, 71, 79);
                    transform-origin: 635.51px 342.75px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <polygon
            points="606.61 197.55 590.59 231.34 675.29 231.34 669.73 197.55 606.61 197.55"
            style="fill: rgb(69, 90, 100); transform-origin: 632.94px 214.445px"
            id="elsxdfeghybf"
            class="animable"
        ></polygon>
        <polygon
            points="571.72 116.71 595.5 133.81 595.73 231.35 590.59 231.35 571.72 116.71"
            style="fill: rgb(69, 90, 100); transform-origin: 583.725px 174.03px"
            id="ely00tz3jkllh"
            class="animable"
        ></polygon>
        <polygon
            points="656.42 116.7 659.24 133.81 595.5 133.81 571.73 116.7 656.42 116.7"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 615.485px 125.255px;
            "
            id="elmcoacc8pgd"
            class="animable"
        ></polygon>
        <g id="elviv369l237j">
            <g
                style="opacity: 0.1; transform-origin: 615.485px 125.255px"
                class="animable"
            >
                <polygon
                    points="656.42 116.7 659.24 133.81 595.5 133.81 571.73 116.7 656.42 116.7"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 615.485px 125.255px;
                    "
                    id="el2phtlhm7lat"
                    class="animable"
                ></polygon>
            </g>
        </g>
        <rect
            x="595.5"
            y="133.81"
            width="79.79"
            height="97.54"
            style="fill: rgb(55, 71, 79); transform-origin: 635.395px 182.58px"
            id="elgro2pba426u"
            class="animable"
        ></rect>
        <rect
            x="604.57"
            y="142.26"
            width="61.64"
            height="80.63"
            style="fill: rgb(38, 50, 56); transform-origin: 635.39px 182.575px"
            id="elydb5q1w2u2k"
            class="animable"
        ></rect>
        <rect
            x="609.51"
            y="147.3"
            width="36.69"
            height="1.58"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 627.855px 148.09px;
            "
            id="elwvvgzhlhdlr"
            class="animable"
        ></rect>
        <rect
            x="609.51"
            y="151.19"
            width="25"
            height="1.58"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 622.01px 151.98px;
            "
            id="el1q0f22zfg7s"
            class="animable"
        ></rect>
        <rect
            x="609.51"
            y="178"
            width="25"
            height="1.58"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 622.01px 178.79px;
            "
            id="elxzshgsctium"
            class="animable"
        ></rect>
        <polygon
            points="675.29 454.15 708.23 454.15 708.23 116.7 656.42 116.7 675.29 231.35 675.29 454.15"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 682.325px 285.425px;
            "
            id="el4t19wlknvfx"
            class="animable"
        ></polygon>
        <g id="el2n3e5iboexu">
            <rect
                x="600.34"
                y="110.06"
                width="113.03"
                height="6.65"
                style="
                    fill: rgb(69, 90, 100);
                    transform-origin: 656.855px 113.385px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eldwkwdkfdahi">
            <rect
                x="661.21"
                y="110.06"
                width="52.16"
                height="6.65"
                style="
                    opacity: 0.1;
                    transform-origin: 687.29px 113.385px;
                    transform: rotate(180deg);
                "
                class="animable"
            ></rect>
        </g>
        <rect
            x="680.43"
            y="116.71"
            width="32.94"
            height="337.44"
            style="fill: rgb(69, 90, 100); transform-origin: 696.9px 285.43px"
            id="elt02g3bml17f"
            class="animable"
        ></rect>
        <g id="eln3dh1t7wuo">
            <rect
                x="597.65"
                y="237.83"
                width="50.19"
                height="6.74"
                style="
                    fill: rgb(255, 255, 255);
                    opacity: 0.2;
                    transform-origin: 622.745px 241.2px;
                "
                class="animable"
            ></rect>
        </g>
        <rect
            x="599.67"
            y="239.97"
            width="46.15"
            height="2.44"
            style="fill: rgb(38, 50, 56); transform-origin: 622.745px 241.19px"
            id="elveanxebaotl"
            class="animable"
        ></rect>
        <g id="eldaygxoaf2l">
            <rect
                x="651.93"
                y="252.75"
                width="18.35"
                height="6.74"
                style="
                    fill: rgb(255, 255, 255);
                    opacity: 0.2;
                    transform-origin: 661.105px 256.12px;
                "
                class="animable"
            ></rect>
        </g>
        <rect
            x="653.95"
            y="254.9"
            width="14.31"
            height="2.44"
            style="fill: rgb(38, 50, 56); transform-origin: 661.105px 256.12px"
            id="elk4expjciv3"
            class="animable"
        ></rect>
        <g id="elzsra1tjutn">
            <g
                style="opacity: 0.2; transform-origin: 661.105px 265.175px"
                class="animable"
            >
                <polygon
                    points="664.1 265.16 662.78 265.16 662.78 269.13 659.44 269.13 659.44 265.16 658.11 265.16 661.11 261.22 664.1 265.16"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 661.105px 265.175px;
                    "
                    id="elrfxc0olxna"
                    class="animable"
                ></polygon>
            </g>
        </g>
        <g id="el0x921u331ukq">
            <rect
                x="651.93"
                y="237.83"
                width="18.35"
                height="11.52"
                style="
                    fill: rgb(255, 255, 255);
                    opacity: 0.2;
                    transform-origin: 661.105px 243.59px;
                "
                class="animable"
            ></rect>
        </g>
        <path
            d="M663.37,243.18c0-.23,0-.47-.09-.7a5.46,5.46,0,0,0-.48-1.41,4.91,4.91,0,0,0-.68-1.06c-.13-.16-.27-.31-.4-.46l0,0h0l-.36.36-.2.19a5,5,0,0,1,0,7l.21.21.36.36h0l.34-.38a5.51,5.51,0,0,0,.59-.84,5.69,5.69,0,0,0,.4-.87,4.86,4.86,0,0,0,.31-1.29c0-.16,0-.32,0-.48S663.38,243.26,663.37,243.18Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 662.267px 243.61px;
            "
            id="eletsa6n8grfp"
            class="animable"
        ></path>
        <path
            d="M661.72,243a4.06,4.06,0,0,0-1.17-2.34l-.57.58a3.33,3.33,0,0,1,0,4.7l.58.57A4.1,4.1,0,0,0,661.72,243Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 660.873px 243.585px;
            "
            id="elieyen9t8a2"
            class="animable"
        ></path>
        <path
            d="M659.4,241.81l-.57.57a1.68,1.68,0,0,1,.5,1.21,1.64,1.64,0,0,1-.5,1.2q.3.28.57.57A2.49,2.49,0,0,0,659.4,241.81Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 659.487px 243.585px;
            "
            id="els3cdy0nsd7"
            class="animable"
        ></path>
        <rect
            x="684.91"
            y="125.62"
            width="21.55"
            height="37.51"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 695.685px 144.375px;
            "
            id="elg9t5c51y0nt"
            class="animable"
        ></rect>
        <path
            d="M696,147.55h-3.65v8.84c0,1.23-.75,2.24-1.66,2.24s-1.64-1-1.64-2.24v-24c0-1.26.74-2.24,1.64-2.24H696c3.54,0,6.4,3.91,6.4,8.76S699.5,147.55,696,147.55ZM692.31,143H696c1.73,0,3.07-1.88,3.1-4.16s-1.37-4.24-3.1-4.24h-3.65Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 695.725px 144.39px;
            "
            id="el5fezk68uu62"
            class="animable"
        ></path>
        <rect
            x="684.91"
            y="170.69"
            width="16.4"
            height="2.36"
            style="fill: rgb(107, 97, 154); transform-origin: 693.11px 171.87px"
            id="elyp9pmd0jh8"
            class="animable"
        ></rect>
        <rect
            x="684.91"
            y="182.17"
            width="9.61"
            height="2.36"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 689.715px 183.35px;
            "
            id="el6fv9xdqe2ln"
            class="animable"
        ></rect>
        <rect
            x="684.91"
            y="176.43"
            width="21.55"
            height="2.36"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 695.685px 177.61px;
            "
            id="elgw8y0rx5k3d"
            class="animable"
        ></rect>
        <rect
            x="621.64"
            y="252.75"
            width="26.2"
            height="26.2"
            style="fill: rgb(38, 50, 56); transform-origin: 634.74px 265.85px"
            id="elyhy1pnzw1v"
            class="animable"
        ></rect>
        <rect
            x="597.65"
            y="252.75"
            width="20.59"
            height="26.2"
            style="fill: rgb(38, 50, 56); transform-origin: 607.945px 265.85px"
            id="el7u5u6urqhha"
            class="animable"
        ></rect>
        <rect
            x="599.14"
            y="260.67"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 600.99px 262.52px"
            id="ela8ifdec7fci"
            class="animable"
        ></rect>
        <rect
            x="603.33"
            y="260.67"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 605.18px 262.52px"
            id="elo3coss3pwpt"
            class="animable"
        ></rect>
        <rect
            x="607.53"
            y="260.67"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 609.38px 262.52px"
            id="elh72g121a06p"
            class="animable"
        ></rect>
        <rect
            x="611.73"
            y="260.69"
            width="4.93"
            height="3.7"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 614.195px 262.54px;
            "
            id="els0v8iac3x8"
            class="animable"
        ></rect>
        <rect
            x="599.14"
            y="264.91"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 600.99px 266.76px"
            id="elqb9fn7gmdtf"
            class="animable"
        ></rect>
        <rect
            x="603.33"
            y="264.91"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 605.18px 266.76px"
            id="eltdk3sqghbq"
            class="animable"
        ></rect>
        <rect
            x="607.53"
            y="264.91"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 609.38px 266.76px"
            id="elwp1k0q7laol"
            class="animable"
        ></rect>
        <rect
            x="611.73"
            y="264.91"
            width="4.93"
            height="3.7"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 614.195px 266.76px;
            "
            id="el0ybj0kgclfj"
            class="animable"
        ></rect>
        <rect
            x="599.14"
            y="269.16"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 600.99px 271.01px"
            id="el65lnobnhx0o"
            class="animable"
        ></rect>
        <rect
            x="603.33"
            y="269.16"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 605.18px 271.01px"
            id="el0x5yigv4ax6p"
            class="animable"
        ></rect>
        <rect
            x="607.53"
            y="269.16"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 609.38px 271.01px"
            id="el2hgietpubp4"
            class="animable"
        ></rect>
        <rect
            x="611.73"
            y="269.16"
            width="4.93"
            height="3.7"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 614.195px 271.01px;
            "
            id="el5bzu31z908n"
            class="animable"
        ></rect>
        <rect
            x="599.14"
            y="273.41"
            width="3.7"
            height="3.7"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 600.99px 275.26px;
            "
            id="elgf595870dl6"
            class="animable"
        ></rect>
        <rect
            x="603.33"
            y="273.41"
            width="3.7"
            height="3.7"
            style="fill: rgb(107, 97, 154); transform-origin: 605.18px 275.26px"
            id="elb95qmtl7zgm"
            class="animable"
        ></rect>
        <rect
            x="607.53"
            y="273.41"
            width="3.7"
            height="3.7"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 609.38px 275.26px;
            "
            id="el192jik35ark"
            class="animable"
        ></rect>
        <rect
            x="611.73"
            y="273.41"
            width="4.93"
            height="3.7"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 614.195px 275.26px;
            "
            id="elv7n8roaskx"
            class="animable"
        ></rect>
        <path
            d="M601.33,262.09l-.39.91s0,.05-.08.05h0a.1.1,0,0,1-.05-.11l.34-.79h-.4a.08.08,0,0,1-.08-.09.07.07,0,0,1,.08-.08h.61v0Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 601.015px 262.515px;
            "
            id="el0olmiuf6latl"
            class="animable"
        ></path>
        <path
            d="M605.52,262.69a.37.37,0,0,1-.73,0,.37.37,0,0,1,.16-.31.25.25,0,0,1-.05-.15.25.25,0,0,1,.26-.25.25.25,0,0,1,.25.25.25.25,0,0,1,0,.15A.37.37,0,0,1,605.52,262.69Zm-.17,0a.19.19,0,0,0-.19-.2.2.2,0,1,0,0,.4A.19.19,0,0,0,605.35,262.69Zm-.28-.46a.09.09,0,0,0,.09.09.09.09,0,0,0,0-.18A.09.09,0,0,0,605.07,262.23Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 605.156px 262.49px;
            "
            id="elzc5nrwoenx"
            class="animable"
        ></path>
        <path
            d="M609,262.35a.38.38,0,0,1,.75,0h0v.09a.89.89,0,0,1,0,.32.51.51,0,0,1-.2.26.45.45,0,0,1-.23.07.08.08,0,0,1-.09-.08.09.09,0,0,1,.08-.09.33.33,0,0,0,.15,0,.24.24,0,0,0,.09-.11l0,0a.32.32,0,0,1-.14,0A.38.38,0,0,1,609,262.35Zm.17,0a.2.2,0,0,0,.21.2.2.2,0,0,0,0-.4A.2.2,0,0,0,609.16,262.35Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 609.378px 262.561px;
            "
            id="ellsoa25x1ymq"
            class="animable"
        ></path>
        <path
            d="M601.4,267a.08.08,0,0,1-.08.08h0v.12a.09.09,0,0,1-.08.09.09.09,0,0,1-.09-.09v-.12h-.54a.08.08,0,0,1,0-.12l.57-.71h.15v.62h0A.09.09,0,0,1,601.4,267Zm-.27-.47-.31.38h.31Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 600.996px 266.77px;
            "
            id="el4ulxomxnlgr"
            class="animable"
        ></path>
        <path
            d="M605.39,266.62a.38.38,0,0,1,.11.27.39.39,0,0,1-.11.27.36.36,0,0,1-.27.12h0a.36.36,0,0,1-.27-.12.07.07,0,0,1,0-.12.09.09,0,0,1,.12,0,.2.2,0,0,0,.15.06.22.22,0,0,0,.15-.06.2.2,0,0,0,.06-.15.2.2,0,0,0-.06-.14.22.22,0,0,0-.3,0,.09.09,0,0,1-.12,0l0,0h0v0l0-.4s0,0,0-.06h.5a.09.09,0,0,1,.09.08.09.09,0,0,1-.09.09H605v.15h.1A.39.39,0,0,1,605.39,266.62Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 605.158px 266.785px;
            "
            id="elib41hiw9s5h"
            class="animable"
        ></path>
        <path
            d="M609.74,266.9a.38.38,0,0,1-.75,0h0v-.09a.93.93,0,0,1,0-.32.56.56,0,0,1,.2-.26.45.45,0,0,1,.23-.07.09.09,0,0,1,0,.17.24.24,0,0,0-.24.15l0,0a.32.32,0,0,1,.14,0A.38.38,0,0,1,609.74,266.9Zm-.17,0a.2.2,0,0,0-.21-.2.2.2,0,0,0-.2.2.2.2,0,0,0,.2.21A.21.21,0,0,0,609.57,266.9Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 609.359px 266.689px;
            "
            id="ellnaevfgyvk"
            class="animable"
        ></path>
        <path
            d="M601.15,270.53v.91a.09.09,0,0,1-.08.09.09.09,0,0,1-.09-.09v-.76l-.06,0h0a.12.12,0,0,1-.08,0,.09.09,0,0,1,0-.12l.19-.11h.13Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 600.989px 270.99px;
            "
            id="elxh8d447xuaj"
            class="animable"
        ></path>
        <path
            d="M605.53,271.44a.09.09,0,0,1-.09.09h-.54a.09.09,0,0,1-.07,0,.08.08,0,0,1,0-.12l.45-.42a.17.17,0,0,0,.07-.14.24.24,0,0,0-.05-.14.22.22,0,0,0-.15-.06.19.19,0,0,0-.14.05l0,0a.08.08,0,0,1-.12,0,.09.09,0,0,1,0-.12l0,0a.38.38,0,0,1,.25-.09.36.36,0,0,1,.27.12.35.35,0,0,1,.1.25.36.36,0,0,1-.12.27l-.29.26h.32A.09.09,0,0,1,605.53,271.44Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 605.167px 271.014px;
            "
            id="el0u03y197mrxc"
            class="animable"
        ></path>
        <path
            d="M609.6,270.87a.39.39,0,0,1,0,.54.36.36,0,0,1-.27.11.35.35,0,0,1-.27-.11.08.08,0,1,1,.12-.12.2.2,0,0,0,.15.06.24.24,0,0,0,.15-.06.21.21,0,0,0-.15-.36.06.06,0,0,1-.06,0h0a.09.09,0,0,1,0-.12l.16-.16h-.25a.09.09,0,1,1,0-.18h.45a.09.09,0,0,1,.09.09s0,0,0,0v0l-.2.2Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 609.377px 270.995px;
            "
            id="elyaraweq9x2d"
            class="animable"
        ></path>
        <path
            d="M601.05,275.56a.11.11,0,1,1,0,.22.11.11,0,0,1,0-.22Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 601.05px 275.67px;
            "
            id="el6914wlspcz3"
            class="animable"
        ></path>
        <path
            d="M604.74,275.23a.66.66,0,0,1,.1-.36.32.32,0,0,1,.58,0,.66.66,0,0,1,.1.36.73.73,0,0,1-.1.37.33.33,0,0,1-.58,0A.73.73,0,0,1,604.74,275.23Zm.61,0a.46.46,0,0,0-.08-.27c0-.06-.09-.1-.14-.09s-.1,0-.15.09a.54.54,0,0,0-.07.27.58.58,0,0,0,.07.28.2.2,0,0,0,.15.09.17.17,0,0,0,.14-.09A.49.49,0,0,0,605.35,275.23Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 605.13px 275.229px;
            "
            id="elxtncianipud"
            class="animable"
        ></path>
        <rect
            x="599.14"
            y="254.34"
            width="17.53"
            height="4.95"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 607.905px 256.815px;
            "
            id="elhmfghmpkk3i"
            class="animable"
        ></rect>
        <ellipse
            cx="634.74"
            cy="265.85"
            rx="9.06"
            ry="12.12"
            style="fill: rgb(55, 71, 79); transform-origin: 634.74px 265.85px"
            id="el7qdh957hc7p"
            class="animable"
        ></ellipse>
        <rect
            x="625.32"
            y="264.76"
            width="18.84"
            height="2.19"
            style="fill: rgb(38, 50, 56); transform-origin: 634.74px 265.855px"
            id="elpgdcomwezh"
            class="animable"
        ></rect>
    </g>
    <g
        id="freepik--Sign--inject-7"
        class="animable"
        style="transform-origin: 96.005px 275.825px"
    >
        <rect
            x="91.99"
            y="91.01"
            width="8.01"
            height="369.63"
            style="
                fill: rgb(199, 199, 199);
                transform-origin: 95.995px 275.825px;
            "
            id="elgvx5t8wawi"
            class="animable"
        ></rect>
        <rect
            x="61.19"
            y="96.71"
            width="69.63"
            height="90.85"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 96.005px 142.135px;
            "
            id="elk5b1gbbkjn"
            class="animable"
        ></rect>
        <path
            d="M125.65,182.29H66.35V102h59.3Zm-58.3-1h57.3V103H67.35Z"
            style="fill: rgb(255, 255, 255); transform-origin: 96px 142.145px"
            id="el1vxfhlbyfwa"
            class="animable"
        ></path>
        <path
            d="M96.69,144.34H87.75v15.77a4,4,0,0,1-8.06,0V117.24a4,4,0,0,1,4-4h13a15.55,15.55,0,1,1,0,31.1Zm-8.94-8.06h8.94a7.49,7.49,0,1,0,0-15H87.75Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 95.9704px 138.69px;
            "
            id="elp2z04z197em"
            class="animable"
        ></path>
        <rect
            x="79.69"
            y="170.17"
            width="31.79"
            height="2.04"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 95.585px 171.19px;
            "
            id="elxnos800vv3p"
            class="animable"
        ></rect>
        <rect
            x="84.82"
            y="174.53"
            width="21.51"
            height="2.04"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 95.575px 175.55px;
            "
            id="elnrt35dqi9yr"
            class="animable"
        ></rect>
    </g>
    <g
        id="freepik--Car--inject-7"
        class="animable"
        style="transform-origin: 311.203px 339.082px"
    >
        <path
            d="M413.69,408.12H550s-14.93-63.69-68.17-63.69S416,393.9,413.69,408.12Z"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 481.845px 376.275px;
            "
            id="eleooi81z7g5f"
            class="animable"
        ></path>
        <g id="el0cpuqrmfvcj">
            <path
                d="M413.69,408.12H550s-14.93-63.69-68.17-63.69S416,393.9,413.69,408.12Z"
                style="opacity: 0.2; transform-origin: 481.845px 376.275px"
                class="animable"
            ></path>
        </g>
        <circle
            cx="479.55"
            cy="404.25"
            r="56.39"
            style="fill: rgb(38, 50, 56); transform-origin: 479.55px 404.25px"
            id="elu101h9klgn"
            class="animable"
        ></circle>
        <g id="ela0nsatpf0vf">
            <circle
                cx="479.55"
                cy="404.25"
                r="41.18"
                style="
                    fill: rgb(219, 219, 219);
                    transform-origin: 479.55px 404.25px;
                    transform: rotate(-76.84deg);
                "
                class="animable"
            ></circle>
        </g>
        <circle
            cx="479.55"
            cy="404.25"
            r="37.97"
            style="
                fill: rgb(166, 166, 166);
                transform-origin: 479.55px 404.25px;
            "
            id="el8hsxqle2t9v"
            class="animable"
        ></circle>
        <path
            d="M485.51,394.73H473.59c4-5.82-10-26.1-10-26.1l6.27-2.1c4.17,7.16,6.26,9.26,9.69,9.26s5.52-2.1,9.7-9.26l6.26,2.1S481.49,388.91,485.51,394.73Z"
            style="
                fill: rgb(219, 219, 219);
                transform-origin: 479.55px 380.63px;
            "
            id="els6olqc55yr"
            class="animable"
        ></path>
        <path
            d="M472.59,395.45l-3.69,11.34c-4.28-5.62-27.91,1.45-27.91,1.45l-.06-6.62c8.1-1.75,10.75-3.09,11.81-6.35s-.3-5.9-5.81-12.09l3.93-5.31S465.82,397.48,472.59,395.45Z"
            style="
                fill: rgb(219, 219, 219);
                transform-origin: 456.76px 393.055px;
            "
            id="elq7a9358j7ph"
            class="animable"
        ></path>
        <path
            d="M469.29,408l9.64,7c-6.67,2.34-7.25,27-7.25,27l-6.31-2c.84-8.25.38-11.17-2.39-13.19s-5.7-1.55-13.3,1.79l-3.82-5.38S469.12,415,469.29,408Z"
            style="fill: rgb(219, 219, 219); transform-origin: 462.395px 425px"
            id="elpx0ts8i9qio"
            class="animable"
        ></path>
        <path
            d="M480.17,415l9.64-7c.17,7.07,23.43,15.24,23.43,15.24l-3.84,5.38c-7.58-3.34-10.5-3.81-13.28-1.79s-3.23,4.94-2.41,13.19l-6.29,2S486.84,417.31,480.17,415Z"
            style="
                fill: rgb(219, 219, 219);
                transform-origin: 496.705px 425.01px;
            "
            id="elxhw8vk0kos"
            class="animable"
        ></path>
        <path
            d="M490.19,406.79l-3.68-11.34c6.77,2,21.73-17.58,21.73-17.58l3.93,5.32c-5.52,6.18-6.87,8.81-5.81,12.08s3.7,4.6,11.81,6.37l-.07,6.6S494.48,401.17,490.19,406.79Z"
            style="
                fill: rgb(219, 219, 219);
                transform-origin: 502.34px 393.055px;
            "
            id="elgl8emcpvinb"
            class="animable"
        ></path>
        <path
            d="M490.57,404a11,11,0,1,1-11-11A11,11,0,0,1,490.57,404Z"
            style="fill: rgb(219, 219, 219); transform-origin: 479.57px 404px"
            id="elnh42dfv5kn"
            class="animable"
        ></path>
        <path
            d="M49.86,401.25H186.2s-14.93-63.7-68.17-63.7S52.2,387,49.86,401.25Z"
            style="fill: rgb(107, 97, 154); transform-origin: 118.03px 369.4px"
            id="el4hz44gvq2rn"
            class="animable"
        ></path>
        <g id="elj104jczb03">
            <path
                d="M49.86,401.25H186.2s-14.93-63.7-68.17-63.7S52.2,387,49.86,401.25Z"
                style="opacity: 0.2; transform-origin: 118.03px 369.4px"
                class="animable"
            ></path>
        </g>
        <path
            d="M54.69,284.61c-2.92,4.65-15.38,56.25-15.68,58s-4.55,9.62-4.62,11.11-1.12,24.55-.52,26a62.34,62.34,0,0,0,4.7,7.83c.74.9,3.06,17.53,5.22,17.75s10.47.38,10.84,0,2.69-61.91,63.33-61.91,60,65.35,61.1,65.57,240.69,6.41,240.69,6.41c0-10,.79-69.52,60.28-69.52,38.75,0,58.33,31.94,59,55.5.28,9.81-1.36,20.59-.82,20.59,1.79,0,7.91.45,8.95,0s13.73-8.8,14.77-9.1,4.11-.45,5.9-.9,14.32-11.41,14.54-11.86.6-4.77.67-5.14,4.26-15.89,4.86-17.61.82-15.89.82-17.31-14.55-35.6-19.92-39.63-39.39-20.64-50.58-22.65-72.73-11.19-75-12.76S336,223.25,317.71,218.82c-14.77-3.58-153.87,1.34-162.82,1.79s-61.76,8.53-63.4,9.28,0,7.31,2.08,8.5C93.57,238.39,59.76,276.56,54.69,284.61Z"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 311.203px 319.832px;
            "
            id="elc5jdbn595k"
            class="animable"
        ></path>
        <g id="el9dx4nv7lhns">
            <path
                d="M463.59,347.68c-43.2,9.88-43.84,58.8-43.84,67.78,0,0-239.58-6.19-240.69-6.42-.91-.19-.64-43-32.67-59.36,14.39,7.12,32.83,24.35,39.81,49.52.76,2.68,8.41,6.89,76,9s126.31.8,137.46-.76S423.87,347.5,463.59,347.68Z"
                style="opacity: 0.1; transform-origin: 304.99px 381.57px"
                class="animable"
            ></path>
        </g>
        <path
            d="M97.59,280.47c2.92,8.62,324.7,24.73,326.64,20.55,1.43-3.09-30.21-28.49-45-36.77S322.18,232,301.37,229.56s-63-2.24-99.81-1.56c-36.48.67-47.57,1.56-62.78,8.05C125.43,241.74,95.27,273.62,97.59,280.47Z"
            style="fill: rgb(38, 50, 56); transform-origin: 260.87px 264.626px"
            id="eljk4lkgkxuxq"
            class="animable"
        ></path>
        <path
            d="M107.45,275.44c.89,3.24,47.11,10.05,138.64,14.3s136.74,6.51,137.86,6.07S380.81,271,379.25,269s-67.14-35.58-77.43-36.48-65.91-.38-94-.56c-34.8-.22-54.73,3.81-64.69,7.84C134.38,243.29,106.55,272.2,107.45,275.44Z"
            style="fill: rgb(55, 71, 79); transform-origin: 245.782px 263.908px"
            id="eli0bcbg7wq1"
            class="animable"
        ></path>
        <g id="el4n21fbrxud">
            <g
                style="opacity: 0.1; transform-origin: 245.797px 263.902px"
                class="animable"
            >
                <path
                    d="M193.07,232.09l-50.13,50.14c-11.32-1.29-19.94-2.55-25.85-3.69l43.41-43.41A231.52,231.52,0,0,1,193.07,232.09Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 155.08px 257.16px;
                    "
                    id="el8niwvzikdgx"
                    class="animable"
                ></path>
                <path
                    d="M384,295.81c-.48.19-9.18-.12-26.27-.89l22.7-22.69C382.24,279.39,384.85,295.45,384,295.81Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 370.948px 284.047px;
                    "
                    id="elsq2vi9ivlo"
                    class="animable"
                ></path>
                <path
                    d="M233.64,231.94,179.88,285.7l-12-1-1.63-.14,52.62-52.62Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 199.945px 258.82px;
                    "
                    id="el0819qe7ppz5"
                    class="animable"
                ></path>
                <path
                    d="M358.67,257.73l-35.61,35.61L309,292.68l39.91-39.89C352.26,254.48,355.57,256.14,358.67,257.73Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 333.835px 273.065px;
                    "
                    id="elajtwbbdvp0e"
                    class="animable"
                ></path>
                <path
                    d="M148.56,237.87,109.7,276.74c-1.39-.47-2.15-.91-2.25-1.29a1.2,1.2,0,0,1,.1-.75l34.36-34.36a10.52,10.52,0,0,1,1.23-.6C144.69,239.12,146.5,238.49,148.56,237.87Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 127.994px 257.305px;
                    "
                    id="elslkrv304g5"
                    class="animable"
                ></path>
                <path
                    d="M367.15,262.12l-31.77,31.8-4-.2,33-33Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 349.265px 277.32px;
                    "
                    id="elrb48i3rjkl7"
                    class="animable"
                ></path>
                <path
                    d="M312.55,236,258.22,290.3l4,.19,53.3-53.3Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 286.87px 263.245px;
                    "
                    id="elknjy71uldgn"
                    class="animable"
                ></path>
            </g>
        </g>
        <path
            d="M204.86,233.33c.57,1.77,1.49,53.75,1.49,55.43s-1.9,2.07-1.9,2.07L234,292.2s-1.91-.53-2.25-1.43-9.62-56.95-9.57-57.68,1.51-1.42,1.51-1.42H203.11A3.09,3.09,0,0,1,204.86,233.33Z"
            style="fill: rgb(38, 50, 56); transform-origin: 218.555px 261.935px"
            id="eld0w4035zqdr"
            class="animable"
        ></path>
        <path
            d="M520.3,314.41c2.24,5.61,23,18.06,31.07,20.75,5.07,1.68,23,5.6,24.15,4.76s-5.59-14.87-9.63-18.65-25.37-15.13-32.23-15.82S518.05,308.76,520.3,314.41Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 547.795px 322.705px;
            "
            id="el0zt0w9ljxqm"
            class="animable"
        ></path>
        <path
            d="M575.52,339.92c-1.2.84-19.07-3.07-24.15-4.77-8.06-2.68-28.83-15.13-31.07-20.74s6.49-9.65,13.36-9a12.64,12.64,0,0,1,1.58.28c-6.71,1.51-8.8,6.55-5.39,10.13s14.75,12.42,19.48,14.63c4.55,2.13,21.89,7.73,23.62,6.68a3.41,3.41,0,0,0,1.08-2.59C575.27,337.4,576,339.61,575.52,339.92Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 547.805px 322.689px;
            "
            id="elo55hga5tbr"
            class="animable"
        ></path>
        <g id="el8wit8db3jr">
            <g
                style="opacity: 0.2; transform-origin: 376.615px 353.66px"
                class="animable"
            >
                <path
                    d="M219.35,296l-2,14.31-.88,7.17c-.13,1.2-.26,2.4-.35,3.61s0,2.41,0,3.62l.26,28.91.23,14.45.12,7.23.06,3.61.28,3.6,1.11,14.41,1.22,14.4-.72-14.42-.84-14.42-.2-3.61,0-3.61-.07-7.21-.14-14.44-.5-28.88c0-1.19-.1-2.41,0-3.6s.18-2.39.28-3.58l.73-7.19Z"
                    id="el132ltth50rr"
                    class="animable"
                    style="transform-origin: 217.74px 353.66px"
                ></path>
                <path
                    d="M416.19,331.36c-.08,9.74-.28,19.46-.54,29.18-.07,2.44-.15,4.86-.26,7.29a32,32,0,0,1-1.21,7.2c-1.16,4.68-2.48,9.3-3.92,13.88a112.89,112.89,0,0,1-5,13.41l-.77,1.61c-.28.52-.59,1-.88,1.54a12.13,12.13,0,0,1-.95,1.49l-.51.71a1.86,1.86,0,0,1-.93.33c-2.12.25-4.21.29-6.32.37-16.81.39-33.62.21-50.42.09s-33.62-.43-50.42-.78-33.61-.89-50.4-1.61c-8.36-.4-16.46-.36-24.81-1.23v-.76c8.33.84,16.46.77,24.83,1.15,16.79.67,33.59,1.08,50.4,1.44s33.6.73,50.4.95,33.61.42,50.41.08c2.09-.07,4.21-.1,6.26-.35.23,0,.55-.11.59-.12l.49-.69a12.18,12.18,0,0,0,.94-1.43c.28-.5.57-1,.85-1.51l.76-1.57a113.1,113.1,0,0,0,5-13.32c1.45-4.56,2.77-9.17,3.93-13.83a29.91,29.91,0,0,0,1.21-7.08l.29-7.28c.34-9.71.62-19.43.76-29.16,0-1.21,0-2.43,0-3.64a13.72,13.72,0,0,0-.18-1.8l-.25-1.8-1-7.2-2-14.41,2.11,14.39,1.05,7.2.26,1.8a12.07,12.07,0,0,1,.19,1.82C416.2,328.93,416.19,330.15,416.19,331.36Z"
                    id="elr3bcu8yuap"
                    class="animable"
                    style="transform-origin: 317.52px 355.559px"
                ></path>
                <path
                    d="M537.17,327.25a65.47,65.47,0,0,1-8.06,5.79c-2.78,1.79-5.62,3.49-8.44,5.21s-5.71,3.34-8.61,4.94-5.79,3.19-8.76,4.66c2.75-1.84,5.56-3.58,8.37-5.33l8.48-5.13,8.55-5,4.28-2.5A42.09,42.09,0,0,0,537.17,327.25Z"
                    id="elr9o1c4qwb8q"
                    class="animable"
                    style="transform-origin: 520.235px 337.55px"
                ></path>
                <polygon
                    points="216.06 359.17 242.91 359.82 269.75 360.57 323.44 362.07 377.12 363.79 403.96 364.66 430.79 365.63 403.94 364.98 377.1 364.23 323.42 362.73 269.74 361 242.9 360.14 216.06 359.17"
                    id="elki8stqbxehp"
                    class="animable"
                    style="transform-origin: 323.425px 362.4px"
                ></polygon>
            </g>
        </g>
        <circle
            cx="116.85"
            cy="404.25"
            r="56.39"
            style="fill: rgb(38, 50, 56); transform-origin: 116.85px 404.25px"
            id="elfr81r2j61ug"
            class="animable"
        ></circle>
        <g id="elfczgmgq4c9">
            <circle
                cx="116.85"
                cy="404.25"
                r="41.18"
                style="
                    fill: rgb(219, 219, 219);
                    transform-origin: 116.85px 404.25px;
                    transform: rotate(-79.21deg);
                "
                class="animable"
            ></circle>
        </g>
        <circle
            cx="116.85"
            cy="404.25"
            r="37.97"
            style="
                fill: rgb(166, 166, 166);
                transform-origin: 116.85px 404.25px;
            "
            id="ely47uiatim2"
            class="animable"
        ></circle>
        <path
            d="M122.81,394.73H110.88c4-5.82-10-26.1-10-26.1l6.27-2.1c4.17,7.16,6.26,9.26,9.69,9.26s5.52-2.1,9.71-9.26l6.26,2.1S118.78,388.91,122.81,394.73Z"
            style="
                fill: rgb(219, 219, 219);
                transform-origin: 116.845px 380.63px;
            "
            id="el05krvjikmr6"
            class="animable"
        ></path>
        <path
            d="M109.88,395.45l-3.68,11.34c-4.29-5.62-27.91,1.45-27.91,1.45l-.06-6.62c8.1-1.75,10.74-3.09,11.8-6.35s-.29-5.9-5.81-12.09l3.93-5.31S103.11,397.48,109.88,395.45Z"
            style="
                fill: rgb(219, 219, 219);
                transform-origin: 94.055px 393.055px;
            "
            id="el30cgybm108g"
            class="animable"
        ></path>
        <path
            d="M106.58,408l9.65,7c-6.68,2.34-7.25,27-7.25,27l-6.31-2c.83-8.25.38-11.17-2.4-13.19s-5.7-1.55-13.29,1.79l-3.83-5.38S106.42,415,106.58,408Z"
            style="fill: rgb(219, 219, 219); transform-origin: 99.69px 425px"
            id="elvkf3xe5espp"
            class="animable"
        ></path>
        <path
            d="M117.46,415l9.65-7c.16,7.07,23.43,15.24,23.43,15.24l-3.84,5.38c-7.59-3.34-10.51-3.81-13.29-1.79s-3.23,4.94-2.4,13.19l-6.3,2S124.13,417.31,117.46,415Z"
            style="fill: rgb(219, 219, 219); transform-origin: 134px 425.01px"
            id="elk9f0osn3mgd"
            class="animable"
        ></path>
        <path
            d="M127.49,406.79l-3.69-11.34c6.78,2,21.73-17.58,21.73-17.58l3.94,5.32c-5.52,6.18-6.87,8.81-5.81,12.08s3.7,4.6,11.8,6.37l-.06,6.6S131.77,401.17,127.49,406.79Z"
            style="
                fill: rgb(219, 219, 219);
                transform-origin: 139.63px 393.055px;
            "
            id="elxfmzikgcfai"
            class="animable"
        ></path>
        <path
            d="M127.87,404a11,11,0,1,1-11-11A11,11,0,0,1,127.87,404Z"
            style="fill: rgb(219, 219, 219); transform-origin: 116.87px 404px"
            id="elc2buavrfc79"
            class="animable"
        ></path>
        <path
            d="M371,274.77c-2.06,2.05-1.87,20.44-.38,21.93s21.94,2.83,23.58-8.58S374.21,271.56,371,274.77Z"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 381.883px 285.752px;
            "
            id="elhga24kncib"
            class="animable"
        ></path>
        <path
            d="M445.59,285.75H429C385.69,257.2,326.31,229,326.31,229l9.85-2.39c35.95,17.41,105.27,57.21,107.09,58.48A9.65,9.65,0,0,0,445.59,285.75Z"
            style="fill: rgb(55, 71, 79); transform-origin: 385.95px 256.18px"
            id="elugsn7f109o"
            class="animable"
        ></path>
        <g id="elltdzh2rd54p">
            <g
                style="opacity: 0.5; transform-origin: 298.21px 297.031px"
                class="animable"
            >
                <path
                    d="M51.61,367.41a72.81,72.81,0,0,1,12.65-15.52A80.13,80.13,0,0,1,80.5,340.06a79,79,0,0,1,38.78-9.54l5,.24,2.52.12c.83.09,1.66.23,2.5.34l5,.71c1.64.35,3.27.78,4.91,1.17a62.18,62.18,0,0,1,18.5,7.93,65,65,0,0,1,15,13.39,89.91,89.91,0,0,1,10.58,17c-3.28-5.81-6.67-11.61-11.09-16.6a64.17,64.17,0,0,0-15-12.93c-11.3-7.05-24.72-9.92-37.94-10.05A81.66,81.66,0,0,0,99.56,334,79.47,79.47,0,0,0,64.7,352.37,76.06,76.06,0,0,0,51.61,367.41Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 117.45px 350.966px;
                    "
                    id="el8jf6gsetiw"
                    class="animable"
                ></path>
                <path
                    d="M413.09,367.41a72.46,72.46,0,0,1,12.64-15.52A80.41,80.41,0,0,1,442,340.06a79,79,0,0,1,38.79-9.54l5,.24,2.52.12c.83.09,1.67.23,2.5.34l5,.71c1.65.35,3.28.78,4.92,1.17A62.12,62.12,0,0,1,519.23,341a64.79,64.79,0,0,1,15,13.39,89.41,89.41,0,0,1,10.58,17c-3.28-5.81-6.67-11.61-11.09-16.6a64,64,0,0,0-15-12.93c-11.3-7.05-24.72-9.92-37.93-10.05A81.74,81.74,0,0,0,461,334a79.47,79.47,0,0,0-34.86,18.39A76,76,0,0,0,413.09,367.41Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 478.95px 350.951px;
                    "
                    id="eloyg6b1jl2s8"
                    class="animable"
                ></path>
                <path
                    d="M71.57,273.83c8.79-6.89,17.7-13.61,26.68-20.25s18-13.14,27.38-19.32c1.18-.75,2.37-1.5,3.59-2.21.61-.36,1.23-.7,1.88-1a11.46,11.46,0,0,1,2.05-.78c2.7-.79,5.41-1.47,8.12-2.15,5.43-1.33,10.86-2.62,16.35-3.69a95.84,95.84,0,0,1,16.7-1.71c5.59-.13,11.18-.11,16.76.15-5.59,0-11.16.16-16.73.5a97.17,97.17,0,0,0-16.52,2.07c-5.43,1.22-10.86,2.48-16.26,3.87-2.7.69-5.4,1.4-8,2.19a11.27,11.27,0,0,0-1.85.71c-.6.31-1.19.64-1.79,1-1.18.7-2.35,1.45-3.52,2.2-9.34,6.05-18.39,12.6-27.5,19Z"
                    style="
                        fill: rgb(255, 255, 255);
                        transform-origin: 131.325px 248.236px;
                    "
                    id="elqoloz7h9w7l"
                    class="animable"
                ></path>
            </g>
        </g>
        <g id="elnv0p23umim9">
            <path
                d="M584,391.46c-.54,2-.91,3.45-.94,3.55-.07.38-.44,4.71-.66,5.15S569.62,411.57,567.83,412s-4.6.58-5.75.86l-.14,0-.33.14-.57.31c-.22.14-.48.28-.76.46l-2,1.24c-4.16,2.59-10.38,6.64-11.1,6.95l-.15.05a4,4,0,0,1-.75.1c-2.06.16-6.56-.15-8-.15-.54,0,1.1-10.79.82-20.59,0-.51,0-1-.08-1.55a1.15,1.15,0,0,0,0-.18c0-.45-.05-.9-.11-1.35a2.46,2.46,0,0,0,0-.28c0-.51-.11-1-.18-1.55s-.12-.87-.19-1.32c-.12-.76-.25-1.51-.41-2.27-.1-.49-.21-1-.32-1.48s-.28-1.13-.44-1.71-.31-1.15-.47-1.71q-.51-1.71-1.14-3.42a.14.14,0,0,0,0-.06c-.2-.56-.42-1.13-.65-1.68a.13.13,0,0,1,0-.05q-.6-1.49-1.29-3-.95-2-2.06-4.05c-.26-.46-.53-.93-.81-1.4s-.64-1.07-1-1.59l-.26-.42-.84-1.26c-.36-.53-.74-1.07-1.13-1.59s-.77-1-1.16-1.55l0,0a59.41,59.41,0,0,0-3.92-4.51c-.46-.49-.94-1-1.42-1.44s-1-.93-1.49-1.39-1-.9-1.53-1.34L516.46,358c-.53-.41-1.08-.82-1.63-1.23l0,0c-.56-.4-1.13-.79-1.71-1.18s-1.18-.77-1.78-1.14c-1.2-.74-2.43-1.44-3.71-2.1,11.13,2.38,29.68,17.56,37.18,33.22s5.57,16.83,7.32,18.71,7.56-1.92,10.24-2.59,11.42-.89,14.79-1.57,3.89-6.7,6.19-8.05A2.72,2.72,0,0,0,584,391.46Z"
                style="opacity: 0.1; transform-origin: 545.815px 387.253px"
                class="animable"
            ></path>
        </g>
        <g id="el5k2bsjis09e">
            <path
                d="M104.61,305.09c.24,10.91-13.19,16.72-21.08,9.16a12.62,12.62,0,0,1-.18-17.9c7.73-7.73,21.28-2.17,21.26,8.74Zm0,0a12,12,0,1,0-20.48,8.55,12,12,0,0,0,20.48-8.55Z"
                style="opacity: 0.2; transform-origin: 92.1648px 305.212px"
                class="animable"
            ></path>
        </g>
        <path
            d="M44.77,317.93s2.47,4.95,2.29,6.36-1.94,16.43-3,17.14-3.46,2-5.53,1.6S44.77,317.93,44.77,317.93Z"
            style="
                fill: rgb(235, 235, 235);
                transform-origin: 42.6341px 330.518px;
            "
            id="elgo3r6m4wa8t"
            class="animable"
        ></path>
        <path
            d="M93.57,238.39s-17.36,21.5-18.51,23.27S60.4,281.32,60.4,281.32l-3.93.76,24.07-31.55Z"
            style="fill: rgb(55, 71, 79); transform-origin: 75.02px 260.235px"
            id="elkg2w3ldpmul"
            class="animable"
        ></path>
        <g id="eltxl8s85ti7">
            <rect
                x="237.09"
                y="304.51"
                width="20.12"
                height="16.6"
                rx="7.07"
                style="opacity: 0.3; transform-origin: 247.15px 312.81px"
                class="animable"
            ></rect>
        </g>
        <rect
            x="229.67"
            y="310.56"
            width="32.22"
            height="5.66"
            rx="1"
            style="fill: rgb(107, 97, 154); transform-origin: 245.78px 313.39px"
            id="elphyplox9qkb"
            class="animable"
        ></rect>
        <g id="elsqiobkccmxh">
            <rect
                x="229.67"
                y="310.56"
                width="32.22"
                height="5.66"
                rx="1"
                style="opacity: 0.1; transform-origin: 245.78px 313.39px"
                class="animable"
            ></rect>
        </g>
    </g>
    <g
        id="freepik--Character--inject-7"
        class="animable"
        style="transform-origin: 576.278px 297.134px"
    >
        <path
            d="M587.31,136.36s-7.76-6-16-2.42-13.55,14.52-13.73,24.39-9,15.06-11,22.12,2.27,11.09,3.28,15.1c1.16,4.59-8.42,18.83,9.52,25.18,22.44,8,33.43-4.93,32.85-17-.28-5.93-2.9-10.51-2.13-15.16s4.61-7.86,3.79-14-3.22-5.7-2.75-15.12S595.25,139.17,587.31,136.36Z"
            style="fill: rgb(38, 50, 56); transform-origin: 570.029px 178.002px"
            id="elj3ej72pq5yq"
            class="animable"
        ></path>
        <path
            d="M573,134A29,29,0,0,0,560,145.45a27.11,27.11,0,0,0-3.23,8.12c-.81,3.74-.77,7.37-2.73,10.82-3.14,5.54-8.39,9.76-9.16,16.33a16.38,16.38,0,0,0,1.48,9c1.55,3.25,4.05,6,5.24,9.44.05.14.27,0,.22-.09-1-3-2.9-5.51-4.4-8.31a16.71,16.71,0,0,1-1.86-10.81c1.12-6.19,6.29-10.3,9.22-15.65a20,20,0,0,0,2.09-7.6,28.23,28.23,0,0,1,2.62-9.18A30.6,30.6,0,0,1,573,134.05C573.07,134,573,133.94,573,134Z"
            style="fill: rgb(38, 50, 56); transform-origin: 558.898px 166.597px"
            id="el3671lg6b1u9"
            class="animable"
        ></path>
        <path
            d="M552.54,203.12a0,0,0,1,0,0,0S552.57,203.13,552.54,203.12Z"
            style="fill: rgb(38, 50, 56); transform-origin: 552.547px 203.122px"
            id="elfdh10vb5xlw"
            class="animable"
        ></path>
        <path
            d="M592.46,202c-.16-2.87-1.23-5.61-1.39-8.47-.19-3.44,1.15-6.64,2.28-9.82,1.62-4.53,2.18-9,.79-13.67-.91-3.05-2.13-6-2.66-9.1a35.3,35.3,0,0,1-.25-10.31.06.06,0,0,0-.12,0,32.37,32.37,0,0,0,.92,14.79c.86,2.82,2.06,5.53,2.35,8.47A23.77,23.77,0,0,1,592.79,184a40.21,40.21,0,0,0-1.91,6.78,19.86,19.86,0,0,0,.61,7.06,24.25,24.25,0,0,1-2.77,17.61c-.06.1.11.2.17.1A23,23,0,0,0,592.46,202Z"
            style="fill: rgb(38, 50, 56); transform-origin: 591.818px 183.081px"
            id="elc8lho1vxi4v"
            class="animable"
        ></path>
        <path
            d="M546.14,179.52c1-5.09,5.08-8,7.92-12.14,2.14-3.11,3.8-6.52,3.81-10.3,0-.06-.11-.06-.11,0-.54,5.39-3.52,9.9-7.16,13.93-2.42,2.68-4.48,5.3-5,8.88s.41,6.69,2,9.89c1.11,2.29,2.22,4.44,2.45,7a26.51,26.51,0,0,1-.78,7.52c0,.12.18.15.21,0,.92-3.79,1.54-7.5.14-11.3C547.83,188.35,545.14,184.69,546.14,179.52Z"
            style="fill: rgb(38, 50, 56); transform-origin: 551.663px 180.718px"
            id="el8wvu8zzv7vb"
            class="animable"
        ></path>
        <path
            d="M593.9,198.51a32.67,32.67,0,0,0-2.19-5.4c-1.53-3.18-1.5-5.57-.33-8.89,0-.07-.09-.12-.12-.05-1.37,2.68-2,5-.67,7.83,1.78,4,3.57,7.62,3.39,12-.31,7.8-5.73,14.3-13.34,17.12-.1,0,0,.19.07.16a19.38,19.38,0,0,0,13.06-12.7A18.55,18.55,0,0,0,593.9,198.51Z"
            style="fill: rgb(38, 50, 56); transform-origin: 587.565px 202.71px"
            id="el13327vxfxokf"
            class="animable"
        ></path>
        <path
            d="M537.28,376.4l-19.64,34.73c-3.15,7-5.79,13.19-6.85,16.52a.11.11,0,0,0,0,.06,5.44,5.44,0,0,0-.46,2.39s0,0,0,.06c1.45,2.35,56.65,29.17,58.89,29.46s3.23-6.07,1.92-8.82-17.86-22.48-17.86-22.48l19.27-34.84Z"
            style="
                fill: rgb(235, 148, 129);
                transform-origin: 541.438px 418.015px;
            "
            id="elhnu8h96soic"
            class="animable"
        ></path>
        <path
            d="M569.21,459.62c-2.23-.28-57.42-27.1-58.88-29.46,0,0,0,0,0-.05a5.24,5.24,0,0,1,.47-2.4s0,0,0,0c.84-2.65,2.67-7.06,4.95-12.26h0c13.06,13.6,49,34.55,49.83,31.92.78-2.3-3.92-8.72-5.05-10.22,4.62,5.64,9.89,12.2,10.61,13.71C572.45,453.54,571.46,459.92,569.21,459.62Z"
            style="fill: rgb(38, 50, 56); transform-origin: 541.026px 437.54px"
            id="elmkarqbti32"
            class="animable"
        ></path>
        <path
            d="M522.18,399.71l39.56,21.12s49.92-71.15,50.92-89.84c1.38-25.82-21.11-107.86-21.11-107.86L556.83,223s14.3,84.29,13.13,98.67C569.36,329.17,522.18,399.71,522.18,399.71Z"
            style="fill: rgb(38, 50, 56); transform-origin: 567.451px 321.915px"
            id="elfenui4slauk"
            class="animable"
        ></path>
        <path
            d="M565.19,412.66c-2-1.47-20.79-12.33-35.06-19.27a.08.08,0,0,0-.08.14c4.33,2.86,32.32,18.19,35,19.28C565.17,412.85,565.28,412.72,565.19,412.66Z"
            style="fill: rgb(55, 71, 79); transform-origin: 547.616px 403.098px"
            id="ellau9s7x02r"
            class="animable"
        ></path>
        <path
            d="M574.85,303.63c-1.64-12.33-3.43-24.65-5.48-36.92s-4.23-24.65-6.81-36.88c-.31-1.49-.64-3-1-4.47a.18.18,0,0,0-.36.07c2.17,12.13,4.4,24.26,6.39,36.42s3.85,24.35,5.52,36.56c.41,3,.82,6,1.21,9.08a82.48,82.48,0,0,1,.9,9.42,24.12,24.12,0,0,1-1.51,8.82,51.59,51.59,0,0,1-4,7.94c-6.36,10.76-34.85,57.79-35.59,59.16-.05.09.07.18.13.09,6.84-10.61,28-44.49,34.5-55.42,2.91-4.94,6.24-9.93,7.19-15.69C576.91,315.83,575.63,309.57,574.85,303.63Z"
            style="fill: rgb(55, 71, 79); transform-origin: 555.198px 309.085px"
            id="elnzenj23seo"
            class="animable"
        ></path>
        <path
            d="M564.72,399.71s-.4,40.12-.4,40.15c.21,7.67.53,14.39,1,17.85a.06.06,0,0,0,0,.06,5.33,5.33,0,0,0,.64,2.35.1.1,0,0,0,0,.05c2.33,1.49,63.69,1.58,65.84.86s.26-6.88-2.12-8.78-25.86-12.45-25.86-12.45V399.72Z"
            style="
                fill: rgb(235, 148, 129);
                transform-origin: 598.53px 430.589px;
            "
            id="elcrstzg388je"
            class="animable"
        ></path>
        <path
            d="M631.87,461c-2.14.72-63.52.63-65.83-.86,0,0,0,0-.06,0a5.66,5.66,0,0,1-.63-2.36v0c-.38-2.67-.66-7.26-.87-12.74,18.3,6.13,58.11,8.8,57.75,6.1S612.8,444,612.8,444l.19-.06c6.88,3.19,15.38,7.21,16.77,8.31C632.13,454.15,634,460.32,631.87,461Z"
            style="fill: rgb(38, 50, 56); transform-origin: 598.641px 452.689px"
            id="ellio8fzjo0wd"
            class="animable"
        ></path>
        <path
            d="M591.55,223.13v0c-.24.72-12.87,35.35-14.06,35.9-1.35.62,27.91,49.78,29.64,72.61,1.11,14.61-1.06,97.26-1.06,97.26H563.28s2.06-74.31,3-97.85c.38-9.13-29.37-54.59-29.73-82.89-.12-8.93,6.29-25.23,6.29-25.23Z"
            style="fill: rgb(38, 50, 56); transform-origin: 571.997px 325.915px"
            id="eluuokj9ye5u"
            class="animable"
        ></path>
        <path
            d="M566.56,330.45c0-.38-.3-.5-.33-.11-1,12.74-1.19,25.41-1.8,38.18s-.26,15.79-.83,28.52c-.32,7.2,0,14.42-.18,21.63a.09.09,0,0,0,.18,0C564.93,406,566.55,337.67,566.56,330.45Z"
            style="fill: rgb(55, 71, 79); transform-origin: 564.99px 374.43px"
            id="ell2ewypo7c1"
            class="animable"
        ></path>
        <path
            d="M607.12,332.18a62.91,62.91,0,0,0-.86-9.38,46.67,46.67,0,0,0-2.64-8.8c-2.37-6-5.16-11.77-7.83-17.6s-5.47-11.78-8.32-17.62q-2.4-4.9-4.84-9.82c-1.64-3.3-3.42-6.55-5.14-9.82a.11.11,0,0,0-.2.1c2.74,5.89,5.45,11.79,8.19,17.68s5.43,11.8,8.13,17.71,5.3,11.63,7.8,17.51a58.4,58.4,0,0,1,3.05,8.65,49.51,49.51,0,0,1,1.25,9.32c.42,7.3.62,14.63,1.34,21.92,0,.09.16.08.16,0C607.43,345.42,607.32,338.78,607.12,332.18Z"
            style="fill: rgb(55, 71, 79); transform-origin: 592.305px 305.586px"
            id="elisjzhy2y5ji"
            class="animable"
        ></path>
        <path
            d="M603,420.48c-2.49-.32-21.44-1-37.3-.3-.1,0-.1.15,0,.16,5.16.46,34.37.66,37.27.33C603,420.65,603.07,420.5,603,420.48Z"
            style="fill: rgb(55, 71, 79); transform-origin: 584.328px 420.354px"
            id="elsfetpxz6xg"
            class="animable"
        ></path>
        <path
            d="M583.39,257.15A81.47,81.47,0,0,0,570,261.79a.14.14,0,0,0,.1.27c4.49-1.4,9-2.72,13.46-4.37A.28.28,0,0,0,583.39,257.15Z"
            style="fill: rgb(55, 71, 79); transform-origin: 576.832px 259.603px"
            id="el1r278bsynfs"
            class="animable"
        ></path>
        <path
            d="M587.71,227.82c0-.15-.26-.21-.27,0a144.58,144.58,0,0,1-2.2,14.3c-.42,2.2-3.46,14.26-7.21,13-.63-.21-.89-.88-.89-1.86a15.12,15.12,0,0,1,.89-3.7c.69-2.52,1.3-5.06,1.78-7.63a70.58,70.58,0,0,0,1.33-14.5.13.13,0,0,0-.25,0,133.69,133.69,0,0,1-3.22,19.88c-.81,3.13-2.9,7.76.38,8.59s6.36-7,7-9.11A74.24,74.24,0,0,0,587.71,227.82Z"
            style="fill: rgb(55, 71, 79); transform-origin: 581.988px 241.648px"
            id="elhwe7vi1gq05"
            class="animable"
        ></path>
        <path
            d="M578.1,255.38a21.73,21.73,0,0,0-1.13,2.45,5.92,5.92,0,0,0-.57,2.05c0,.14.18.17.26.08a7.12,7.12,0,0,0,1.1-1.94c.37-.75.76-1.5,1.11-2.26A.43.43,0,0,0,578.1,255.38Z"
            style="fill: rgb(55, 71, 79); transform-origin: 577.652px 257.586px"
            id="elyf2pp4hqdb"
            class="animable"
        ></path>
        <path
            d="M570.94,343c.22-6.08.89-12.46-1.1-18.33a61.15,61.15,0,0,0-3.9-8.32q-2.24-4.29-4.37-8.62c-5.72-11.55-11.1-23.28-15.91-35.23a74.69,74.69,0,0,1-5.22-17.84,54.7,54.7,0,0,1,1.2-19.41c.36-1.58.74-3.15,1.17-4.72,0-.11-.14-.18-.17-.06a63.76,63.76,0,0,0-3.34,18.56,52.4,52.4,0,0,0,3.22,17.73c2.05,6,4.62,11.78,7.15,17.56q3.9,8.94,8.13,17.74c2.8,5.83,5.78,11.57,8.73,17.32a31.29,31.29,0,0,1,3.29,8.75,45,45,0,0,1,.35,9.57c-.5,13.45-1.66,58.23-1.83,71.65,0,1.71-.05,3.41-.06,5.11a.12.12,0,1,0,.23,0C569.36,401.11,570.46,356.44,570.94,343Z"
            style="fill: rgb(55, 71, 79); transform-origin: 555.264px 322.511px"
            id="elry33ontg9lp"
            class="animable"
        ></path>
        <path
            d="M561.34,231.85c0-.1-.15-.08-.16,0-.5,3.7-.79,7.54-2.58,10.9a15.23,15.23,0,0,1-7.62,6.46,57.66,57.66,0,0,1-5.55,2.05c-.14,0-.11.25,0,.22,3.54-.73,7.14-1.56,10.21-3.55a12.77,12.77,0,0,0,5.53-9.34A32.41,32.41,0,0,0,561.34,231.85Z"
            style="fill: rgb(55, 71, 79); transform-origin: 553.389px 241.632px"
            id="elt6k5fj5hb1i"
            class="animable"
        ></path>
        <path
            d="M542.7,222.94l48.85.19-2.69-14a11.72,11.72,0,0,0,3.59-8.83c-.28-4.57-9.21-20.49-11.08-23.47-3.4-5.46-11.3-6.09-15-2-9.73,10.68-14.25,25.83-17.7,36.36Z"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 567.578px 197.655px;
            "
            id="ely2pdazzl05l"
            class="animable"
        ></path>
        <path
            d="M577,206.31a24.75,24.75,0,0,1,5.21.91c.86.27,1.7.59,2.55.94.42.17.85.32,1.27.47a3.81,3.81,0,0,0,1.35.29s0,.09,0,.09a5.12,5.12,0,0,1-2.5-.21c-.87-.25-1.74-.57-2.61-.84a52.73,52.73,0,0,0-5.27-1.43C576.87,206.51,576.87,206.3,577,206.31Z"
            style="fill: rgb(38, 50, 56); transform-origin: 582.141px 207.694px"
            id="ele1k023sq51h"
            class="animable"
        ></path>
        <path
            d="M572.88,208.92a24.48,24.48,0,0,1,4.24-.61,17.15,17.15,0,0,1,2.15,0l1,.1c.38.05.75.17,1.13.21,0,0,.05.09,0,.09-.36,0-.71.05-1.07.06l-1.07,0-2.13.08c-1.43,0-2.85.07-4.28.18C572.82,209.1,572.81,208.94,572.88,208.92Z"
            style="fill: rgb(38, 50, 56); transform-origin: 577.125px 208.662px"
            id="el6ewenrr1v25"
            class="animable"
        ></path>
        <path
            d="M570.62,174.64c.23,1,4.89,7.39,9.38,7.2,1.47-.06,1.48-8.07,1.48-8.07l.14-.59,1.89-8.27-9.69-6.3-1.4-.83s-.37,2.29-.81,5.16l-.06.41a4,4,0,0,0-.07.46c-.07.43-.14.87-.2,1.3s-.1.66-.14,1-.08.69-.13,1A54.6,54.6,0,0,0,570.62,174.64Z"
            style="
                fill: rgb(235, 148, 129);
                transform-origin: 577.061px 169.812px;
            "
            id="elomvcxv9cez"
            class="animable"
        ></path>
        <path
            d="M571.61,162.94a17,17,0,0,0,10,10.24l1.89-8.27-9.69-6.3-1.4-.83S572.05,160.07,571.61,162.94Z"
            style="fill: rgb(38, 50, 56); transform-origin: 577.555px 165.48px"
            id="elsdv8yac2l69"
            class="animable"
        ></path>
        <path
            d="M596,153.51c.37,14.9-8.51,16.8-11.72,16.88-2.92.06-12.85-.07-14.76-14.85s4.9-19.65,11.56-20.16S595.59,138.62,596,153.51Z"
            style="
                fill: rgb(235, 148, 129);
                transform-origin: 582.602px 152.866px;
            "
            id="elhj70gewat0v"
            class="animable"
        ></path>
        <path
            d="M594,150.54c-.35,0-.67-.15-1-.23a1.63,1.63,0,0,1-1-.43.53.53,0,0,1,0-.65,1.32,1.32,0,0,1,1.31-.3,2,2,0,0,1,1.22.71A.58.58,0,0,1,594,150.54Z"
            style="fill: rgb(38, 50, 56); transform-origin: 593.258px 149.705px"
            id="elz7xxul7lwer"
            class="animable"
        ></path>
        <path
            d="M584.15,151.38c.35-.06.67-.16,1-.25a1.76,1.76,0,0,0,1-.46.53.53,0,0,0,0-.65,1.31,1.31,0,0,0-1.32-.26,2,2,0,0,0-1.2.74A.57.57,0,0,0,584.15,151.38Z"
            style="fill: rgb(38, 50, 56); transform-origin: 584.899px 150.532px"
            id="elcnuaw0k9y9d"
            class="animable"
        ></path>
        <path
            d="M585.92,154.25s-.08.05-.08.09c.08,1,0,2.21-.91,2.59a0,0,0,0,0,0,.06C586.06,156.78,586.16,155.2,585.92,154.25Z"
            style="fill: rgb(38, 50, 56); transform-origin: 585.478px 155.62px"
            id="elsv69h46idyr"
            class="animable"
        ></path>
        <path
            d="M585,153.22c-1.65-.06-1.64,3.25-.11,3.3S586.34,153.26,585,153.22Z"
            style="fill: rgb(38, 50, 56); transform-origin: 584.887px 154.87px"
            id="eld5wgvh4tgh"
            class="animable"
        ></path>
        <path
            d="M584.31,153.39c-.29.19-.57.52-.92.56s-.71-.3-1-.64c0,0-.06,0-.06,0,0,.64.24,1.29.92,1.38s1.06-.48,1.22-1.12C584.53,153.49,584.43,153.32,584.31,153.39Z"
            style="fill: rgb(38, 50, 56); transform-origin: 583.409px 154.005px"
            id="elbvtcawfhlgi"
            class="animable"
        ></path>
        <path
            d="M591.84,154.17s.08.05.08.1c-.07,1,0,2.2.94,2.58,0,0,0,.06,0,.05C591.72,156.7,591.62,155.13,591.84,154.17Z"
            style="fill: rgb(38, 50, 56); transform-origin: 592.303px 155.536px"
            id="el508ti35tf2h"
            class="animable"
        ></path>
        <path
            d="M592.8,153.13c1.65-.06,1.66,3.25.13,3.31S591.41,153.19,592.8,153.13Z"
            style="fill: rgb(38, 50, 56); transform-origin: 592.914px 154.785px"
            id="elp8urnhczr8e"
            class="animable"
        ></path>
        <path
            d="M593.49,153.35c.26.17.52.49.83.51s.63-.34.86-.68c0,0,.05,0,.05,0,0,.63-.18,1.29-.79,1.41s-1-.43-1.12-1.06C593.29,153.46,593.38,153.28,593.49,153.35Z"
            style="fill: rgb(38, 50, 56); transform-origin: 594.272px 153.893px"
            id="elsswtyf9kae"
            class="animable"
        ></path>
        <path
            d="M585.57,162.26c.21.27.41.63.78.71a2.68,2.68,0,0,0,1.12-.11,0,0,0,0,1,0,.06,1.4,1.4,0,0,1-1.36.38,1.08,1.08,0,0,1-.68-1C585.46,162.23,585.54,162.22,585.57,162.26Z"
            style="fill: rgb(38, 50, 56); transform-origin: 586.45px 162.791px"
            id="el6t0z83oauch"
            class="animable"
        ></path>
        <path
            d="M590.23,159.52a22.1,22.1,0,0,1,0,2.26c0,.07-.18.09-.43.09h0a3.43,3.43,0,0,1-3.23-1.54c-.05-.07,0-.14.11-.09a5.22,5.22,0,0,0,3.06,1.14c.07-.2-.25-2.64-.13-2.64a6.45,6.45,0,0,1,1.6.49c-.1-3.22-.72-6.39-.78-9.6a.1.1,0,0,1,.2,0,52.19,52.19,0,0,1,1.27,10.31C592,160.32,590.51,159.67,590.23,159.52Z"
            style="fill: rgb(38, 50, 56); transform-origin: 589.228px 155.709px"
            id="eldpb07a32gtc"
            class="animable"
        ></path>
        <path
            d="M571.63,156.87c2.72.31,3.34-5.92,3.34-5.92s11.54-2.09,12.41-11.51a15.91,15.91,0,0,0,8.13,8.62s-.52-10.31-8.72-12.22c0,0-10.2-3.58-15.81,4.54S569.81,156.66,571.63,156.87Z"
            style="fill: rgb(38, 50, 56); transform-origin: 581.874px 145.968px"
            id="elavwrosfjsu6"
            class="animable"
        ></path>
        <path
            d="M587.41,138.74a10.21,10.21,0,0,1-.47,4.31,10.52,10.52,0,0,1-2.13,3.82,8.32,8.32,0,0,1-.78.79l-.39.39-.44.33c-.3.22-.58.44-.89.65l-1,.53-.48.26-.51.2-1,.4c-.7.2-1.4.37-2.1.52.66-.29,1.34-.52,2-.82l.95-.48.48-.23.44-.29.89-.57c.28-.2.55-.44.82-.65l.41-.33.37-.37a7.42,7.42,0,0,0,.72-.76,12.21,12.21,0,0,0,2.16-3.56,11.79,11.79,0,0,0,.62-2A12.47,12.47,0,0,0,587.41,138.74Z"
            style="fill: rgb(38, 50, 56); transform-origin: 582.343px 144.84px"
            id="elftxfybyxwy"
            class="animable"
        ></path>
        <path
            d="M573.33,156.13s-3-4.84-5.13-3.82-.15,7.91,2.26,9a2.52,2.52,0,0,0,3.45-1.14Z"
            style="
                fill: rgb(235, 148, 129);
                transform-origin: 570.602px 156.885px;
            "
            id="elslwyulahsz"
            class="animable"
        ></path>
        <path
            d="M568.83,154.27s-.05,0,0,.06c1.69.81,2.5,2.48,3,4.19a1.39,1.39,0,0,0-2.05-.51s0,.1,0,.09a1.55,1.55,0,0,1,1.67.65,7.69,7.69,0,0,1,.73,1.43c.07.15.35.09.31-.09l0,0C572.71,157.84,571.19,154.64,568.83,154.27Z"
            style="fill: rgb(38, 50, 56); transform-origin: 570.659px 157.268px"
            id="eloqs8at2qhcf"
            class="animable"
        ></path>
        <path
            d="M548,286.61,585.52,283c10.14-1,7.73-8.92,4.49-17.2s-8.08-20.82-17.14-19.95l-9.73.93-9.74.93c-9.06.87-11.42,14.11-13,22.85S537.9,287.58,548,286.61Z"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 566.119px 266.247px;
            "
            id="elsazif0o9n9"
            class="animable"
        ></path>
        <g id="elpmanibrqc">
            <path
                d="M548,286.61,585.52,283c10.14-1,7.73-8.92,4.49-17.2s-8.08-20.82-17.14-19.95l-9.73.93-9.74.93c-9.06.87-11.42,14.11-13,22.85S537.9,287.58,548,286.61Z"
                style="opacity: 0.3; transform-origin: 566.119px 266.247px"
                class="animable"
            ></path>
        </g>
        <path
            d="M574.32,245.75a.39.39,0,1,1-.35.43A.39.39,0,0,1,574.32,245.75Zm-6.74,1a.39.39,0,1,0,.35-.43A.39.39,0,0,0,567.58,246.79Zm-6.39.61a.39.39,0,0,0,.78-.07.4.4,0,0,0-.43-.35A.39.39,0,0,0,561.19,247.4Zm-6.39.61a.39.39,0,1,0,.35-.42A.39.39,0,0,0,554.8,248Zm26.35,5.77a.39.39,0,1,0,.35-.43A.39.39,0,0,0,581.15,253.78Zm-6.39.61a.39.39,0,0,0,.42.35.39.39,0,1,0-.42-.35Zm-6.39.61a.39.39,0,1,0,.35-.42A.38.38,0,0,0,568.37,255Zm-6.39.61a.38.38,0,0,0,.42.35.38.38,0,0,0,.35-.42.39.39,0,0,0-.42-.35A.38.38,0,0,0,562,255.61Zm-6.39.62a.39.39,0,1,0,.35-.43A.39.39,0,0,0,555.59,256.23Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,549.2,256.84Zm28.35-7a.38.38,0,0,0,.42.35.38.38,0,0,0,.35-.42.38.38,0,0,0-.42-.35A.39.39,0,0,0,577.55,249.87Zm-6.39.61a.39.39,0,0,0,.42.36.4.4,0,0,0,.35-.43.39.39,0,1,0-.77.07Zm-6.39.62a.39.39,0,1,0,.35-.43A.39.39,0,0,0,564.77,251.1Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,558.38,251.71Zm-6.39.61a.39.39,0,0,0,.42.35.39.39,0,1,0-.42-.35Zm-6.32.8a.36.36,0,0,0,.35.16.38.38,0,0,0,.35-.42.4.4,0,0,0-.3-.35C545.93,252.71,545.8,252.91,545.67,253.12ZM581.94,262a.38.38,0,0,0,.42.35.39.39,0,0,0,.35-.42.38.38,0,0,0-.42-.35A.38.38,0,0,0,581.94,262Zm-6.4.61a.39.39,0,1,0,.78-.07.39.39,0,0,0-.78.07Zm-6.39.62a.39.39,0,1,0,.35-.43A.39.39,0,0,0,569.15,263.22Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,562.76,263.83Zm-6.39.61a.39.39,0,0,0,.78-.07.39.39,0,0,0-.78.07Zm-6.39.61a.39.39,0,1,0,.35-.42A.39.39,0,0,0,550,265.05Zm-6.39.61a.38.38,0,0,0,.43.35.39.39,0,1,0-.43-.35Zm41.14-8.18a.39.39,0,0,0,.42.35.4.4,0,0,0,.35-.43.39.39,0,1,0-.77.08Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,578.34,258.09Zm-6.39.61a.39.39,0,1,0,.35-.43A.4.4,0,0,0,572,258.7Zm-6.39.61a.39.39,0,0,0,.77-.07.38.38,0,0,0-.42-.35A.38.38,0,0,0,565.56,259.31Zm-6.39.61a.38.38,0,0,0,.42.35.39.39,0,0,0,.35-.42.38.38,0,0,0-.42-.35A.38.38,0,0,0,559.17,259.92Zm-6.4.61a.4.4,0,0,0,.43.36.41.41,0,0,0,.35-.43.39.39,0,0,0-.78.07Zm-6.39.62a.39.39,0,1,0,.35-.43A.39.39,0,0,0,546.38,261.15Zm42.73,8.45a.39.39,0,0,0,.43.35.41.41,0,0,0,.35-.43.39.39,0,0,0-.78.08Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,582.72,270.21Zm-6.39.61a.39.39,0,1,0,.35-.43A.41.41,0,0,0,576.33,270.82Zm-6.39.61a.39.39,0,0,0,.78-.07.4.4,0,0,0-.43-.35A.39.39,0,0,0,569.94,271.43Zm-6.39.61a.38.38,0,0,0,.42.35.38.38,0,0,0,.35-.42.38.38,0,0,0-.42-.35A.39.39,0,0,0,563.55,272Zm-6.39.62a.39.39,0,0,0,.42.35.4.4,0,0,0,.35-.43.39.39,0,1,0-.77.08Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,550.77,273.27Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,544.38,273.88Zm41.13-8.19a.39.39,0,1,0,.35-.43A.41.41,0,0,0,585.51,265.69Zm-6.39.61a.39.39,0,0,0,.78-.07.39.39,0,0,0-.78.07Zm-6.39.61a.39.39,0,1,0,.35-.42A.39.39,0,0,0,572.73,266.91Zm-6.39.62a.39.39,0,0,0,.43.35.41.41,0,0,0,.35-.43.39.39,0,0,0-.78.08Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,560,268.14Zm-6.39.61a.39.39,0,1,0,.35-.43A.4.4,0,0,0,553.56,268.75Zm-6.39.61a.39.39,0,0,0,.78-.07.4.4,0,0,0-.43-.35A.39.39,0,0,0,547.17,269.36Zm-6.39.61a.38.38,0,0,0,.42.35.38.38,0,0,0,.35-.42.38.38,0,0,0-.42-.35A.39.39,0,0,0,540.78,270Zm49.12,7.84a.39.39,0,0,0,.42.35.38.38,0,0,0,.35-.42.39.39,0,0,0-.42-.36A.41.41,0,0,0,589.9,277.81Zm-6.39.61a.39.39,0,1,0,.35-.42A.38.38,0,0,0,583.51,278.42Zm-6.39.61a.39.39,0,0,0,.77-.07.39.39,0,0,0-.42-.35A.38.38,0,0,0,577.12,279Zm-6.39.62a.39.39,0,0,0,.42.35.4.4,0,0,0,.35-.43.39.39,0,1,0-.77.08Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,564.34,280.26Zm-6.39.61a.39.39,0,1,0,.35-.43A.4.4,0,0,0,558,280.87Zm-6.39.61a.39.39,0,1,0,.77-.07.39.39,0,1,0-.77.07Zm-6.39.61a.38.38,0,0,0,.42.35.39.39,0,0,0,.35-.42.38.38,0,0,0-.42-.35A.38.38,0,0,0,545.17,282.09Zm41.13-8.19a.38.38,0,0,0,.42.35.38.38,0,0,0,.35-.42.39.39,0,0,0-.77.07Zm-6.39.62a.39.39,0,0,0,.42.35.4.4,0,0,0,.35-.43.39.39,0,1,0-.77.08Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,573.52,275.13Zm-6.39.61a.39.39,0,0,0,.42.35.38.38,0,0,0,.35-.42.39.39,0,0,0-.42-.36A.4.4,0,0,0,567.13,275.74Zm-6.39.61a.39.39,0,0,0,.42.35.39.39,0,1,0-.42-.35Zm-6.39.61a.39.39,0,1,0,.35-.42A.38.38,0,0,0,554.35,277Zm-6.39.62a.39.39,0,0,0,.42.35.4.4,0,0,0,.35-.43.39.39,0,1,0-.77.08Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,541.57,278.19Zm45.52,3.93a.39.39,0,1,0,.35-.43A.39.39,0,0,0,587.09,282.12Zm-6.39.61a.39.39,0,1,0,.35-.43A.4.4,0,0,0,580.7,282.73Zm-6.39.61a.38.38,0,0,0,.42.35.39.39,0,0,0,.35-.42.39.39,0,0,0-.77.07Zm-6.39.61a.38.38,0,0,0,.42.35.39.39,0,0,0-.07-.77A.38.38,0,0,0,567.92,284Zm-6.4.62a.41.41,0,0,0,.43.35.4.4,0,0,0,.35-.43.39.39,0,0,0-.42-.35A.39.39,0,0,0,561.52,284.57Zm-6.39.61a.39.39,0,1,0,.35-.43A.39.39,0,0,0,555.13,285.18Zm-6.39.61a.39.39,0,1,0,.35-.43A.41.41,0,0,0,548.74,285.79Zm-6,.19a1,1,0,0,0,.22.09A.4.4,0,0,0,542.78,286Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 565.724px 265.948px;
            "
            id="elzy9rz2i81ha"
            class="animable"
        ></path>
        <g id="elklwgtvw1ygc">
            <path
                d="M570.82,250.58a3.12,3.12,0,1,0,2.81-3.4A3.12,3.12,0,0,0,570.82,250.58Z"
                style="opacity: 0.1; transform-origin: 573.926px 250.286px"
                class="animable"
            ></path>
        </g>
        <g id="el7vox5b882vw">
            <path
                d="M550.1,252.57a3.12,3.12,0,1,0,2.81-3.41A3.11,3.11,0,0,0,550.1,252.57Z"
                style="opacity: 0.1; transform-origin: 553.205px 252.266px"
                class="animable"
            ></path>
        </g>
        <path
            d="M571.82,250.48a2.11,2.11,0,1,0,1.91-2.3A2.12,2.12,0,0,0,571.82,250.48Z"
            style="fill: rgb(38, 50, 56); transform-origin: 573.921px 250.281px"
            id="elq18czsnqo38"
            class="animable"
        ></path>
        <path
            d="M551.1,252.47a2.11,2.11,0,1,0,1.9-2.31A2.11,2.11,0,0,0,551.1,252.47Z"
            style="fill: rgb(38, 50, 56); transform-origin: 553.2px 252.261px"
            id="elzyjzzjtuuu9"
            class="animable"
        ></path>
        <path
            d="M554.55,252.55l-2-.07,0-.91c1.29-37.87,2.51-73.63,14.59-78.33l.72,1.86c-10.85,4.22-12.1,41-13.31,76.54Z"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 560.205px 212.895px;
            "
            id="el9fr6u17dqy4"
            class="animable"
        ></path>
        <path
            d="M574.93,250.31l-2-.06c0-.44,1.26-44.1.53-56-.66-10.62-2.45-17.68-4.79-18.89a1.66,1.66,0,0,0-1.76.24l-1.06-1.69a3.6,3.6,0,0,1,3.73-.33c3.93,2,5.36,12.29,5.87,20.55C576.2,206.12,574.94,249.87,574.93,250.31Z"
            style="
                fill: rgb(69, 90, 100);
                transform-origin: 570.769px 211.759px;
            "
            id="elazio4ouf6y9"
            class="animable"
        ></path>
        <path
            d="M563.37,181.14c-3.11,8.39-9.23,43.87-5.66,48.34,8.94,11.2,26.44,24.31,32.21,29,1.44,1.16,15.39-22.2,11.64-24.61-5.84-3.74-24.56-13.9-25.53-15-1.66-2-2.52-22.9-4.25-35.29C570.22,172.32,565.21,176.19,563.37,181.14Z"
            style="
                fill: rgb(235, 148, 129);
                transform-origin: 579.411px 217.396px;
            "
            id="el1cq88c2sitd"
            class="animable"
        ></path>
        <path
            d="M611.48,246.33c-.89-1.4-.16-1.88,2.63-.9s13,7.22,14.88,3.47-12.66-12.34-17.43-13.61-12.94-1.66-12.94-1.66C601.12,235.87,606.65,241.88,611.48,246.33Z"
            style="
                fill: rgb(235, 148, 129);
                transform-origin: 613.888px 241.859px;
            "
            id="el6fkjryixaey"
            class="animable"
        ></path>
        <path
            d="M638.55,244.8,642.18,257a1.31,1.31,0,0,1-.87,1.61L621.9,264.4a1.3,1.3,0,0,1-1.61-.87l-3.62-12.24a1.2,1.2,0,0,1,.81-1.5l19.58-5.8A1.2,1.2,0,0,1,638.55,244.8Z"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 629.424px 254.197px;
            "
            id="elepzydgv59zi"
            class="animable"
        ></path>
        <g id="elpbq9aenqiz">
            <path
                d="M638.55,244.8,642.18,257a1.31,1.31,0,0,1-.87,1.61L621.9,264.4a1.3,1.3,0,0,1-1.61-.87l-3.62-12.24a1.2,1.2,0,0,1,.81-1.5l19.58-5.8A1.2,1.2,0,0,1,638.55,244.8Z"
                style="opacity: 0.3; transform-origin: 629.424px 254.197px"
                class="animable"
            ></path>
        </g>
        <path
            d="M622.32,253.73l-1.27.38a1.47,1.47,0,0,1-1.84-1h0a1.47,1.47,0,0,1,1-1.84l1.27-.37a1.47,1.47,0,0,1,1.84,1h0A1.47,1.47,0,0,1,622.32,253.73Z"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 621.264px 252.505px;
            "
            id="elhyf6f4nhuaa"
            class="animable"
        ></path>
        <path
            d="M620.24,257.16l-.14.15v0H620a.06.06,0,0,1,0-.06l.19-.21s0,0,.06,0l0,0,.32,1.09a0,0,0,0,1,0,.05s0,0-.05,0Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 620.281px 257.61px;
            "
            id="elsgtd04g7k8"
            class="animable"
        ></path>
        <path
            d="M620.91,258.05l.41-.67a.32.32,0,0,0,0-.25.4.4,0,0,0-.15-.19.36.36,0,0,0-.25,0,.33.33,0,0,0-.19.14l0,.07a0,0,0,0,1-.06,0,0,0,0,0,1,0-.06l0-.07a.44.44,0,0,1,.23-.18.42.42,0,0,1,.33,0,.44.44,0,0,1,.18.23.42.42,0,0,1,0,.33l-.35.57.56-.17s0,0,0,0a0,0,0,0,1,0,.06l-.66.19h0A0,0,0,0,1,620.91,258.05Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 621.145px 257.428px;
            "
            id="el6o7etx9wztk"
            class="animable"
        ></path>
        <path
            d="M622.33,256.5l-.21.4a.48.48,0,0,1,.23.05.44.44,0,0,1,.2.25.4.4,0,0,1,0,.32.42.42,0,0,1-.25.21.4.4,0,0,1-.32,0,0,0,0,0,1,0-.06,0,0,0,0,1,.06,0,.31.31,0,0,0,.25,0,.29.29,0,0,0,.2-.16.32.32,0,0,0,0-.25.35.35,0,0,0-.16-.2.37.37,0,0,0-.25,0h0a0,0,0,0,1,0-.06l.2-.4-.45.14a0,0,0,0,1-.06,0s0,0,0-.06l.56-.16a0,0,0,0,1,.05,0s0,0,0,0Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 622.177px 257.132px;
            "
            id="el6spyw204bm7"
            class="animable"
        ></path>
        <path
            d="M623.59,257.07l-.65.19h0a0,0,0,0,1,0-.05l.43-1.07h0a0,0,0,0,1,.06,0l0,0h0l.24.81.08,0a0,0,0,0,1,0,0,0,0,0,0,1,0,0l-.08,0,.06.2a0,0,0,0,1,0,.05,0,0,0,0,1-.05,0Zm0-.08-.2-.7-.36.87Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 623.345px 256.7px;
            "
            id="el9tl4iolls1"
            class="animable"
        ></path>
        <path
            d="M625.12,256.76s0,0,0-.06a0,0,0,0,1,.06,0,.31.31,0,0,0,.25,0,.27.27,0,0,0,.2-.16.32.32,0,0,0,0-.25.39.39,0,0,0-.16-.2.31.31,0,0,0-.25,0,.29.29,0,0,0-.2.16,0,0,0,0,1-.06,0v0h0l-.09-.5a.06.06,0,0,1,0,0l0,0,.56-.16a0,0,0,0,1,0,0,0,0,0,0,1,0,.06l-.52.15.07.37a.36.36,0,0,1,.18-.12.44.44,0,0,1,.32,0,.43.43,0,0,1,.2.26.4.4,0,0,1,0,.32.41.41,0,0,1-.25.2A.45.45,0,0,1,625.12,256.76Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 625.292px 256.212px;
            "
            id="elb6u3okhoj27"
            class="animable"
        ></path>
        <path
            d="M626,255.61a.53.53,0,0,1,.34-.39.06.06,0,0,1,.06,0,.07.07,0,0,1,0,.06.4.4,0,0,0-.28.32.74.74,0,0,0,0,.26.4.4,0,1,1,0,.3s0-.05,0-.08A1,1,0,0,1,626,255.61Zm.14.55v0h0a.32.32,0,0,0,.39.18.32.32,0,0,0,.22-.4.33.33,0,0,0-.41-.22.32.32,0,0,0-.22.4Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 626.445px 255.811px;
            "
            id="elbwuyr1mwh44"
            class="animable"
        ></path>
        <path
            d="M627.38,256.15l.13-1.18-.57.18a0,0,0,0,1,0-.09l.63-.18h0l0,0h0v0l-.14,1.23s0,0,0,0h0S627.38,256.17,627.38,256.15Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 627.255px 255.517px;
            "
            id="elzah89rb47wn"
            class="animable"
        ></path>
        <path
            d="M628.22,254.67a.25.25,0,0,1,.32.17.24.24,0,0,1,0,.23.42.42,0,0,1,.35.29.41.41,0,0,1-.27.5.42.42,0,0,1-.51-.27.41.41,0,0,1,.14-.43.25.25,0,0,1-.16-.17A.25.25,0,0,1,628.22,254.67Zm.33,1.11a.32.32,0,1,0-.18-.61.32.32,0,0,0,.18.61Zm-.2-.7a.16.16,0,0,0,.11-.21.16.16,0,0,0-.21-.12.16.16,0,0,0-.12.21A.17.17,0,0,0,628.35,255.08Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 628.489px 255.266px;
            "
            id="elnffho84ilfe"
            class="animable"
        ></path>
        <path
            d="M630.34,254a.42.42,0,0,1,.5.23h0l0,.1a1,1,0,0,1,0,.51.52.52,0,0,1-.34.38h0s0,0,0,0a0,0,0,0,1,0-.06.43.43,0,0,0,.29-.32.75.75,0,0,0,0-.26.4.4,0,0,1-.26.21.41.41,0,0,1-.51-.27A.41.41,0,0,1,630.34,254Zm.43.3a.32.32,0,1,0-.62.18.32.32,0,0,0,.4.22A.32.32,0,0,0,630.77,254.34Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 630.438px 254.602px;
            "
            id="elb5ue79xbtzo"
            class="animable"
        ></path>
        <path
            d="M631.21,254.43a.86.86,0,0,1,0-.45.42.42,0,0,1,.25-.27.41.41,0,0,1,.35.09.78.78,0,0,1,.24.38.77.77,0,0,1,0,.45.38.38,0,0,1-.25.27.36.36,0,0,1-.35-.09A.86.86,0,0,1,631.21,254.43Zm.09,0a.64.64,0,0,0,.21.34.29.29,0,0,0,.27.08.3.3,0,0,0,.18-.21.68.68,0,0,0,0-.4.79.79,0,0,0-.21-.34.35.35,0,0,0-.28-.08.3.3,0,0,0-.18.22A.58.58,0,0,0,631.3,254.4Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 631.632px 254.307px;
            "
            id="elodbov3yn9ie"
            class="animable"
        ></path>
        <path
            d="M632.45,253.55l-.14.14a0,0,0,0,1,0,0h0s0,0,0-.06l.19-.21s0,0,.06,0a0,0,0,0,1,0,0l.33,1.09s0,0,0,0,0,0,0,0Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 632.6px 253.965px;
            "
            id="el8jxxpar6ik8"
            class="animable"
        ></path>
        <path
            d="M633.12,254.43l.41-.66a.31.31,0,0,0,0-.26.28.28,0,0,0-.14-.18.32.32,0,0,0-.25,0,.38.38,0,0,0-.19.14l0,.07a0,0,0,0,1-.06,0,0,0,0,0,1,0-.06l0-.07a.41.41,0,0,1,.23-.18.4.4,0,0,1,.32,0,.36.36,0,0,1,.18.23.39.39,0,0,1,0,.33l-.35.57.57-.16s0,0,0,0,0,0,0,.05l-.66.2h0A0,0,0,0,1,633.12,254.43Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 633.365px 253.823px;
            "
            id="ellfx8cl5b60a"
            class="animable"
        ></path>
        <path
            d="M635.56,252.58l-.22.4a.52.52,0,0,1,.24.05.43.43,0,0,1,.17.57.42.42,0,0,1-.25.21.4.4,0,0,1-.32,0,0,0,0,0,1,0-.06,0,0,0,0,1,.06,0,.31.31,0,0,0,.25,0,.32.32,0,0,0,.2-.16.37.37,0,0,0,0-.25.35.35,0,0,0-.16-.2.39.39,0,0,0-.26,0h0a0,0,0,0,1,0-.06l.21-.4-.46.14s0,0-.05,0,0,0,0-.06l.56-.16s0,0,0,0v0Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 635.373px 253.212px;
            "
            id="elrziozwniinp"
            class="animable"
        ></path>
        <path
            d="M636.82,253.15l-.65.19h0s0,0,0-.05l.43-1.07h0a0,0,0,0,1,.06,0l0,0h0l.24.81.08,0a0,0,0,0,1,.06,0s0,0,0,0l-.08,0,.06.2a0,0,0,0,1,0,0,0,0,0,0,1,0,0Zm0-.08-.21-.7-.35.87Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 636.605px 252.78px;
            "
            id="elvttfme0fxxl"
            class="animable"
        ></path>
        <path
            d="M637.33,253.14a0,0,0,0,1,0-.06,0,0,0,0,1,.06,0,.37.37,0,0,0,.25,0,.39.39,0,0,0,.2-.16.4.4,0,0,0,0-.26.39.39,0,0,0-.16-.2.33.33,0,0,0-.26,0,.3.3,0,0,0-.19.16s0,0-.06,0h0l-.08-.5s0,0,0,0h0l.55-.17a.06.06,0,0,1,.06,0,0,0,0,0,1,0,.06l-.52.15.06.37a.39.39,0,0,1,.19-.12.4.4,0,0,1,.32,0,.39.39,0,0,1,.2.25.41.41,0,0,1-.28.52A.44.44,0,0,1,637.33,253.14Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 637.53px 252.57px;
            "
            id="elxvb69mlv5wg"
            class="animable"
        ></path>
        <path
            d="M638.22,252a.49.49,0,0,1,.34-.38s.05,0,.05,0a0,0,0,0,1,0,.06.41.41,0,0,0-.29.32.75.75,0,0,0,0,.26.41.41,0,1,1,0,.3l0-.07A1.1,1.1,0,0,1,638.22,252Zm.13.55a0,0,0,0,0,0,0v0a.33.33,0,0,0,.39.17.32.32,0,0,0,.22-.4.32.32,0,1,0-.62.18Z"
            style="
                fill: rgb(248, 248, 248);
                transform-origin: 638.666px 252.22px;
            "
            id="eliuqughks7te"
            class="animable"
        ></path>
        <g id="elnizou27zjaj">
            <rect
                x="621.17"
                y="258.68"
                width="10.84"
                height="0.53"
                style="
                    fill: rgb(55, 71, 79);
                    transform-origin: 626.59px 258.945px;
                    transform: rotate(-16.51deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="eltfu1kssmq5">
            <rect
                x="621.57"
                y="260.27"
                width="7.67"
                height="0.53"
                style="
                    fill: rgb(55, 71, 79);
                    transform-origin: 625.405px 260.535px;
                    transform: rotate(-16.51deg);
                "
                class="animable"
            ></rect>
        </g>
        <g id="el66f56wv8j0i">
            <rect
                x="627.73"
                y="248.25"
                width="5.41"
                height="0.53"
                style="
                    fill: rgb(55, 71, 79);
                    transform-origin: 630.435px 248.515px;
                    transform: rotate(-16.51deg);
                "
                class="animable"
            ></rect>
        </g>
        <g
            id="freepik--u5Zjqx--inject-7"
            class="animable"
            style="transform-origin: 636.801px 247.505px"
        >
            <path
                d="M637.38,248.57l-.12-.07-.07,0a1.4,1.4,0,0,0,.11-1.06,1.36,1.36,0,0,0-.67-.82l0-.07a.54.54,0,0,0,.07-.13h0a1.19,1.19,0,0,1,.15.09,1.13,1.13,0,0,1,.26.23,1.16,1.16,0,0,1,.24.34,1.42,1.42,0,0,1,.08.18,1.54,1.54,0,0,1,0,.17l0,.13a1.51,1.51,0,0,1,0,.37,2,2,0,0,1,0,.26,1.07,1.07,0,0,1-.09.27l-.06.13Z"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 637.036px 247.505px;
                "
                id="el5zypn65r4gn"
                class="animable"
            ></path>
            <path
                d="M636.42,247a1.28,1.28,0,0,1,.11-.2,1.17,1.17,0,0,1,.5.53,1.19,1.19,0,0,1,0,1l-.2-.11a.92.92,0,0,0-.37-1.26Z"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 636.78px 247.565px;
                "
                id="el01f8oj1clic6"
                class="animable"
            ></path>
            <path
                d="M636.59,248.13l-.2-.11a.45.45,0,0,0,0-.36.51.51,0,0,0-.23-.29l.11-.19A.69.69,0,0,1,636.59,248.13Z"
                style="
                    fill: rgb(255, 255, 255);
                    transform-origin: 636.415px 247.655px;
                "
                id="elcva3vnj6bdd"
                class="animable"
            ></path>
        </g>
        <path
            d="M584.24,253.68c7.26,6.06,15.92,14,26.44,15.77a5.28,5.28,0,0,0,3.42-.5c4.7.86,6.51-1.1,6.51-1.1,4.63-.54,6.21-2.8,6.21-2.8s5.53.95,6.66-2.3c1.28-3.64-6.74-4.26-10.94-7.3-9.61-7-21.34-19.54-23.92-21.82Z"
            style="
                fill: rgb(235, 148, 129);
                transform-origin: 608.928px 251.587px;
            "
            id="elpds434iuan"
            class="animable"
        ></path>
        <path
            d="M607.34,255.24a75.3,75.3,0,0,0,8.76,5.62,76.72,76.72,0,0,0,10.66,4.07.09.09,0,0,1,0,.18,40.35,40.35,0,0,1-19.47-9.74C607.12,255.26,607.19,255.14,607.34,255.24Z"
            style="fill: rgb(38, 50, 56); transform-origin: 617.02px 260.156px"
            id="elj20fufd1aqm"
            class="animable"
        ></path>
        <path
            d="M602.29,260.44c2.9,1.78,8,4.88,18.35,7.3,0,0,0,.07,0,.06a36.19,36.19,0,0,1-18.42-7.22C602,260.45,602.1,260.32,602.29,260.44Z"
            style="fill: rgb(38, 50, 56); transform-origin: 611.367px 264.097px"
            id="el3zkt3xmcvk"
            class="animable"
        ></path>
        <path
            d="M599.63,263.28c5,2.85,8.6,4,14.45,5.64,0,0,0,.07,0,.06-6.85-1.16-9.2-2.36-14.56-5.54C599.33,263.33,599.44,263.17,599.63,263.28Z"
            style="fill: rgb(38, 50, 56); transform-origin: 606.751px 266.112px"
            id="eli3zwnwxw1ml"
            class="animable"
        ></path>
        <path
            d="M598.26,230.63l-14.9,25S561.16,238.54,556,229c-2.3-4.3,1.6-30.93,5.43-43.65s10.94-15.88,12,1.22c1.32,20.84,2.55,30.24,3.19,31.21S598.26,230.63,598.26,230.63Z"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 576.787px 215.198px;
            "
            id="elhcv4d2xohmg"
            class="animable"
        ></path>
        <path
            d="M579.28,250.43c1.27-1.66,2.31-3.51,3.41-5.29s2.15-3.5,3.21-5.26c2.14-3.56,4.38-7.1,6.28-10.78,0-.09-.07-.17-.13-.08-2.5,3.36-4.66,7-6.83,10.56-1.09,1.8-2.16,3.6-3.2,5.42a53.17,53.17,0,0,0-2.88,5.36C579.1,250.45,579.23,250.5,579.28,250.43Z"
            style="fill: rgb(38, 50, 56); transform-origin: 585.656px 239.722px"
            id="elcadsz9ds2e9"
            class="animable"
        ></path>
        <path
            d="M584.26,254.15l-.87,1.53,0,0q-7.8-5.94-15.13-12.47c-2.44-2.17-4.81-4.42-7.08-6.78s-4.71-4.75-5.74-8.06c-.77-6.58.14-13.09,1-19.59a143.52,143.52,0,0,1,3.93-19.17,173.94,173.94,0,0,0-3.36,19.24c-.68,6.39-1.6,13-.79,19.38.92,3,3.46,5.42,5.51,7.73,2.23,2.36,4.6,4.59,7,6.81,4.79,4.42,9.73,8.67,14.74,12.84h0l.93-1.5Z"
            style="fill: rgb(38, 50, 56); transform-origin: 569.775px 222.645px"
            id="elz0s7hmglr7"
            class="animable"
        ></path>
        <path
            d="M559.26,191c-.19,1.57-.28,3.11-.32,4.69a9.11,9.11,0,0,1,.32-4.69Z"
            style="fill: rgb(38, 50, 56); transform-origin: 559.016px 193.345px"
            id="eli0skso957d"
            class="animable"
        ></path>
        <path
            d="M584.51,222.69a77.45,77.45,0,0,1-7.75-4.6,1.05,1.05,0,0,1-.39-.57,181.3,181.3,0,0,1-2.73-28.67c.09,2.74.57,6.77.81,9.56.71,6.31,1.15,12.76,2.29,19,0,.32.43.52.72.77,2.29,1.6,4.68,3.05,7,4.52Z"
            style="fill: rgb(38, 50, 56); transform-origin: 579.075px 205.775px"
            id="el84h96c3hkpt"
            class="animable"
        ></path>
        <path
            d="M573.8,193.84c.29-1.43.35-2.87.58-4.32a8.72,8.72,0,0,1-.58,4.32Z"
            style="fill: rgb(38, 50, 56); transform-origin: 574.121px 191.68px"
            id="el2s8ig90ex1w"
            class="animable"
        ></path>
    </g>
    <g
        id="freepik--speech-bubble--inject-7"
        class="animable"
        style="transform-origin: 532.245px 105.972px"
    >
        <path
            d="M501.47,105.93A29.14,29.14,0,0,0,548,129.33L562.27,133l-5.94-13.29a29.15,29.15,0,1,0-54.86-13.75Z"
            style="
                fill: rgb(255, 255, 255);
                transform-origin: 531.87px 105.955px;
            "
            id="elexcyivpxd8c"
            class="animable"
        ></path>
        <path
            d="M501.47,105.93a29.06,29.06,0,0,0,31.65,28.8,28.74,28.74,0,0,0,14.79-5.79l.17,0,14.3,3.57-.51.6-6-13.28-.1-.21.11-.21A29.17,29.17,0,0,0,559.28,107c.68-13.2-8.76-25.93-21.64-29-18.09-4.87-36.22,9.29-36.17,28Zm0,0c.72-31.73,42.57-40.68,56.2-12a29.41,29.41,0,0,1-.92,26l0-.42,5.9,13.32.37.83-.88-.23-14.26-3.73.3-.06a29.4,29.4,0,0,1-15,5.6c-16.87,1.41-31.81-12.34-31.69-29.28Z"
            style="fill: rgb(38, 50, 56); transform-origin: 532.245px 105.972px"
            id="ell4mq0uk9hnh"
            class="animable"
        ></path>
        <polygon
            points="526.08 123.27 513.01 110.05 517.4 105.71 525.03 113.44 540.89 88.58 546.09 91.9 526.08 123.27"
            style="
                fill: rgb(107, 97, 154);
                transform-origin: 529.55px 105.925px;
            "
            id="elmipziza70db"
            class="animable"
        ></polygon>
    </g>
    <defs>
        <filter id="active" height="200%">
            <feMorphology
                in="SourceAlpha"
                result="DILATED"
                operator="dilate"
                radius="2"
            ></feMorphology>
            <feFlood
                flood-color="#32DFEC"
                flood-opacity="1"
                result="PINK"
            ></feFlood>
            <feComposite
                in="PINK"
                in2="DILATED"
                operator="in"
                result="OUTLINE"
            ></feComposite>
            <feMerge>
                <feMergeNode in="OUTLINE"></feMergeNode>
                <feMergeNode in="SourceGraphic"></feMergeNode>
            </feMerge>
        </filter>
        <filter id="hover" height="200%">
            <feMorphology
                in="SourceAlpha"
                result="DILATED"
                operator="dilate"
                radius="2"
            ></feMorphology>
            <feFlood
                flood-color="#ff0000"
                flood-opacity="0.5"
                result="PINK"
            ></feFlood>
            <feComposite
                in="PINK"
                in2="DILATED"
                operator="in"
                result="OUTLINE"
            ></feComposite>
            <feMerge>
                <feMergeNode in="OUTLINE"></feMergeNode>
                <feMergeNode in="SourceGraphic"></feMergeNode>
            </feMerge>
            <feColorMatrix
                type="matrix"
                values="0   0   0   0   0                0   1   0   0   0                0   0   0   0   0                0   0   0   1   0 "
            ></feColorMatrix>
        </filter>
    </defs>
</svg>

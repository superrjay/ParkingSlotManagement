<?php 
include '../php/connections.php';
include '../php/fetchLoginData.php';
include_once '../php/parkingFunction.php';
$current_page = 'StaffSlotManagement'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slot Management</title>
    <link rel="icon" href="../img/logo.png">
    <!-- Libraries -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../lib/css/sweetalert.css">
    <link rel="stylesheet" href="../lib/css/toastr.css">
    <link rel="stylesheet" href="../lib/css/flatpickr.min.css">
    <link rel="stylesheet" href="../lib/icons/css/all.css"/>
    <script src="../lib/js/jquery-3.7.1.min.js"></script>
    <script src="../lib/js/bootstrap.bundle.js"></script>
    <script src="../lib/js/qrious.min.js"></script>
    <script src="../lib/js/sweetalert.js"></script>
    <script src="../lib/js/toastr.js"></script>
    <script src="../lib/js/flatpickr.min.js"></script>
    <!-- Styling -->
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<div class="loader-container" id="loader-container">
    <div class="loader">
  <div class="box" style="--i: 1; --inset:44%">
    <div class="logo">
        <img src="../img/logo.png" alt="">
    </div>
  </div>
  <div class="box" style="--i: 2; --inset:40%"></div>
  <div class="box" style="--i: 3; --inset:36%"></div>
  <div class="box" style="--i: 4; --inset:32%"></div>
  <div class="box" style="--i: 5; --inset:28%"></div>
  <div class="box" style="--i: 6; --inset:24%"></div>
  <div class="box" style="--i: 7; --inset:20%"></div>
  <div class="box" style="--i: 8; --inset:16%"></div>
</div>
    </div>


    <header>
        <div class="navbar">
        <div class="header-logo"><a href="#"><img src="../img/logo.png" alt=""></a></div>
        </div>
    </header>
            
    <section>

<!-- Include the left sidebar -->
<?php include '../components/sidebarLeft.php'; ?>

<div class="main-section">
    <?php include '../components/cards.php'; ?>
    <div class="parking-container">
        <?php
        $fetchParking = fetchParking();
        ?>
        <div class="table-container">
            <table class="parking-table">
                <thead>
                    <tr>
                        <th>Floor</th>
                        <th>Zone</th>
                        <th>Slot</th>
                        <th>Plate Number</th>
                        <th>Vehicle</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    // Filter for occupied slots
                    $occupiedSlots = array_filter($fetchParking, function($parkingData) {
                        return $parkingData['status'] === 'Occupied' && 'Overstay'; 
                    });

                    if (empty($occupiedSlots)) {
                        // If no occupied slots are available
                        echo "<tr><td colspan='4'>No parking data available.</td></tr>";
                    } else {
                        // Display occupied slots
                        foreach ($occupiedSlots as $parkingData): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($parkingData['floor']); ?></td>
                        <td><?php echo htmlspecialchars($parkingData['zone']); ?></td>
                        <td><?php echo htmlspecialchars($parkingData['slot_number']); ?></td>
                        <td><?php echo htmlspecialchars($parkingData['plate_number']); ?></td>
                        <td><?php echo htmlspecialchars($parkingData['vehicle_type']); ?></td>
                        <td><?php echo htmlspecialchars($parkingData['status']); ?></td>
                        <td>
                            <button
                            class="view-btn"
                            data-slot-id="<?php echo htmlspecialchars($parkingData['slot_id']); ?>" 
                            data-floor="<?php echo htmlspecialchars($parkingData['floor']); ?>" 
                            data-zone="<?php echo htmlspecialchars($parkingData['zone']); ?>" 
                            data-slot-number="<?php echo htmlspecialchars($parkingData['slot_number']); ?>" 
                            data-plate-number="<?php echo htmlspecialchars($parkingData['plate_number']); ?>"
                            data-user-type="<?php echo htmlspecialchars($parkingData['user_type']); ?>" 
                            data-vehicle-type="<?php echo htmlspecialchars($parkingData['vehicle_type']); ?>"
                            data-status="<?php echo htmlspecialchars($parkingData['status']); ?>"
                            data-time-in="<?php echo htmlspecialchars($parkingData['time_in']); ?>"
                            data-toggle="modal"
                            data-target="#slotModal" >View
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; 
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="filter-container">
            <form id="filterForm">
            <div class="filter-header">Filter
            <button type="button" id="resetFilter">Reset Filter</button>
            </div>
            <div class="filter-actions">
                <div class="search-container">
                    <input type="search" id="search" autocomplete="off" placeholder="Search...">
                </div>
                <div class="checkbox-container">
                    <h4>Filter By:</h4>
                    <div class="floor-input-container">
                                <h5>Floor</h5>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="floors[]" id="filterFloor" value="1" required>
                                    <span class="filter-checkbox-tile">1</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="floors[]" id="filterFloor" value="2" required>
                                    <span class="filter-checkbox-tile">2</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="floors[]" id="filterFloor" value="3" required>
                                    <span class="filter-checkbox-tile">3</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="floors[]" id="filterFloor" value="4" required>
                                    <span class="filter-checkbox-tile">4</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="floors[]" id="filterFloor" value="5" required>
                                    <span class="filter-checkbox-tile">5</span>
                                </label>
                            </div>
                            <div class="zone-input-container">
                            <h5>Zone</h5>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="zones[]" id="filterZone" value="A" required>
                                    <span class="filter-checkbox-tile">A</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="zones[]" id="filterZone" value="B" required>
                                    <span class="filter-checkbox-tile">B</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="zones[]" id="filterZone" value="C" required>
                                    <span class="filter-checkbox-tile">C</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="zones[]" id="filterZone" value="D" required>
                                    <span class="filter-checkbox-tile">D</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="zones[]" id="filterZone" value="E" required>
                                    <span class="filter-checkbox-tile">E</span>
                                </label>
                                <label>
                                    <input type="checkbox" class="filter-checkbox-input" name="zones[]" id="filterZone" value="F" required>
                                    <span class="filter-checkbox-tile">F</span>
                                </label>
                            </div>
                            <div class="vehicle-input-container">
                            <h5>Vehicle</h5>
                        <label>
                            <input class="vehicle-input" type="checkbox" name="vehicle_types[]" id="filterVehicle" value="Bicycle" required>
                                <span class="vehicle-tile">
                                    <span class="vehicle-icon">
                                        <svg stroke="currentColor" xml:space="preserve" viewBox="0 0 493.407 493.407" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" id="Capa_1" version="1.1" width="200px" height="200px" fill="none"><g stroke-width="0" id="SVGRepo_bgCarrier"></g><g stroke-linejoin="round" stroke-linecap="round" id="SVGRepo_tracerCarrier"></g><g id="SVGRepo_iconCarrier"> <path d="M488.474,270.899c-12.647-37.192-47.527-62.182-86.791-62.182c-5.892,0-11.728,0.749-17.499,1.879l-34.324-100.94 c-1.71-5.014-6.417-8.392-11.721-8.392H315.02c-6.836,0-12.382,5.547-12.382,12.382c0,6.836,5.545,12.381,12.382,12.381h14.252 l12.462,36.645H206.069v-21.998l21.732-2.821c3.353-0.434,6.135-3.079,6.585-6.585c0.54-4.183-2.402-8.013-6.585-8.553l-68.929-8.94 c-1.362-0.168-2.853-0.185-4.281,0c-9.116,1.186-15.55,9.537-14.373,18.653c1.185,9.118,9.537,15.55,18.653,14.364l22.434-2.909 v26.004l-41.255,52.798c-14.059-8.771-30.592-13.93-48.349-13.93C41.135,208.757,0,249.885,0,300.443 c0,50.565,41.135,91.7,91.701,91.7c44.882,0,82.261-32.437,90.113-75.095h33.605v12.647h-5.909c-4.563,0-8.254,3.693-8.254,8.254 c0,4.563,3.691,8.254,8.254,8.254h36.58c4.563,0,8.254-3.691,8.254-8.254c0-4.561-3.691-8.254-8.254-8.254h-5.908v-12.647h5.545 c3.814,0,7.409-1.756,9.755-4.756l95.546-122.267l9.776,28.729c-17.854,8.892-32.444,22.965-41.409,41.168 c-10.825,21.973-12.438,46.842-4.553,70.034c12.662,37.201,47.55,62.189,86.815,62.189c10.021,0,19.951-1.645,29.519-4.9 c23.191-7.885,41.926-24.329,52.744-46.302C494.746,318.966,496.367,294.09,488.474,270.899z M143.46,258.542 c7.698,9.488,12.776,21.014,14.349,33.742h-40.717L143.46,258.542z M91.701,367.379c-36.912,0-66.938-30.026-66.938-66.936 c0-36.904,30.026-66.923,66.938-66.923c12.002,0,23.11,3.427,32.864,8.981l-42.619,54.54c-2.917,3.732-3.448,8.794-1.378,13.05 c2.08,4.256,6.4,6.957,11.134,6.957h64.592C148.861,345.906,122.84,367.379,91.701,367.379z M239.69,292.284h-56.707 c-1.839-20.667-10.586-39.329-23.868-53.782l22.191-28.398v32.47c0,6.836,5.545,12.381,12.381,12.381 c6.836,0,12.382-5.545,12.382-12.381v-55.138h115.553L239.69,292.284z M383.546,285.618l6.384,18.79 c1.75,5.151,6.562,8.392,11.721,8.392c1.321,0,2.667-0.21,3.99-0.661c6.471-2.201,9.93-9.23,7.729-15.711l-6.336-18.637 c7.731,1.838,14.221,7.312,16.855,15.083c2.024,5.94,1.613,12.309-1.161,17.935c-2.773,5.626-7.569,9.835-13.509,11.858 c-12.068,4.078-25.716-2.717-29.785-14.671C376.735,300.055,378.597,291.689,383.546,285.618z M461.712,329.994 c-7.908,16.042-21.579,28.044-38.507,33.808c-6.997,2.378-14.244,3.578-21.547,3.578c-28.664,0-54.129-18.249-63.374-45.399 c-5.757-16.926-4.571-35.081,3.328-51.112c6.047-12.27,15.494-22.112,27.165-28.666l8.981,26.416 c-13.414,10.108-19.644,27.931-13.954,44.691c5.522,16.227,20.732,27.124,37.853,27.124c4.378,0,8.707-0.725,12.882-2.145 c10.108-3.434,18.282-10.607,22.999-20.184c4.723-9.585,5.425-20.435,1.982-30.551c-5.545-16.299-21.57-26.787-38.289-26.818 l-8.997-26.472c3.128-0.453,6.28-0.783,9.448-0.783c28.658,0,54.112,18.242,63.351,45.399 C470.788,295.799,469.613,313.96,461.712,329.994z"></path> </g></svg>
                                    </span>
                                    <span class="vehicle-label">Bicycle</span>
                                </span>
                        </label>
                        <label>
                            <input class="vehicle-input" type="checkbox" name="vehicle_types[]" id="filterVehicle" value="Motorcycle" required>
                            <span class="vehicle-tile">
                                <span class="vehicle-icon">
                                <svg stroke="currentColor" xml:space="preserve" viewBox="0 0 467.168 467.168" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" id="Capa_1" version="1.1" fill="none"><g stroke-width="0" id="SVGRepo_bgCarrier"></g><g stroke-linejoin="round" stroke-linecap="round" id="SVGRepo_tracerCarrier"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M76.849,210.531C34.406,210.531,0,244.937,0,287.388c0,42.438,34.406,76.847,76.849,76.847 c30.989,0,57.635-18.387,69.789-44.819l18.258,14.078c0,0,134.168,0.958,141.538-3.206c0,0-16.65-45.469,4.484-64.688 c2.225-2.024,5.021-4.332,8.096-6.777c-3.543,8.829-5.534,18.45-5.534,28.558c0,42.446,34.403,76.846,76.846,76.846 c42.443,0,76.843-34.415,76.843-76.846c0-42.451-34.408-76.849-76.843-76.849c-0.697,0-1.362,0.088-2.056,0.102 c5.551-3.603,9.093-5.865,9.093-5.865l-5.763-5.127c0,0,16.651-3.837,12.816-12.167c-3.848-8.33-44.19-58.28-44.19-58.28 s7.146-15.373-7.634-26.261l-7.098,15.371c0,0-18.093-12.489-25.295-10.084c-7.205,2.398-18.005,3.603-21.379,8.884l-3.358,3.124 c0,0-0.95,5.528,4.561,13.693c0,0,55.482,17.05,58.119,29.537c0,0,3.848,7.933-12.728,9.844l-3.354,4.328l-8.896,0.479 l-16.082-36.748c0,0-15.381,4.082-23.299,10.323l1.201,6.24c0,0-64.599-43.943-125.362,21.137c0,0-44.909,12.966-76.37-26.897 c0,0-0.479-12.968-76.367-10.565l5.286,5.524c0,0-5.286,0.479-7.444,3.841c-2.158,3.358,1.2,6.961,18.494,6.961 c0,0,39.153,44.668,69.17,42.032l42.743,20.656l18.975,32.42c0,0,0.034,2.785,0.23,7.045c-4.404,0.938-9.341,1.979-14.579,3.09 C139.605,232.602,110.832,210.531,76.849,210.531z M390.325,234.081c29.395,0,53.299,23.912,53.299,53.299 c0,29.39-23.912,53.294-53.299,53.294c-29.394,0-53.294-23.912-53.294-53.294C337.031,257.993,360.932,234.081,390.325,234.081z M76.849,340.683c-29.387,0-53.299-23.913-53.299-53.295c0-29.395,23.912-53.299,53.299-53.299 c22.592,0,41.896,14.154,49.636,34.039c-28.26,6.011-56.31,11.99-56.31,11.99l3.619,19.933l55.339-2.444 C124.365,322.116,102.745,340.683,76.849,340.683z M169.152,295.835c1.571,5.334,3.619,9.574,6.312,11.394l-24.696,0.966 c1.058-3.783,1.857-7.666,2.338-11.662L169.152,295.835z"></path> </g> </g> </g></svg>
                                </span>
                                <span class="vehicle-label">Motorcycle</span>
                            </span>
                        </label>
                        <label>
                            <input class="vehicle-input" type="checkbox" name="vehicle_types[]" id="filterVehicle" value="Car" required>
                            <span class="vehicle-tile">
                                <span class="vehicle-icon">
                                <svg stroke="currentColor" xml:space="preserve" viewBox="0 0 324.018 324.017" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" id="Capa_1" version="1.1" fill="none"><g stroke-width="0" id="SVGRepo_bgCarrier"></g><g stroke-linejoin="round" stroke-linecap="round" id="SVGRepo_tracerCarrier"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M317.833,197.111c3.346-11.148,2.455-20.541-2.65-27.945c-9.715-14.064-31.308-15.864-35.43-16.076l-8.077-4.352 l-0.528-0.217c-8.969-2.561-42.745-3.591-47.805-3.733c-7.979-3.936-14.607-7.62-20.475-10.879 c-20.536-11.413-34.107-18.958-72.959-18.958c-47.049,0-85.447,20.395-90.597,23.25c-2.812,0.212-5.297,0.404-7.646,0.59 l-6.455-8.733l7.34,0.774c2.91,0.306,4.267-1.243,3.031-3.459c-1.24-2.216-4.603-4.262-7.519-4.57l-23.951-2.524 c-2.91-0.305-4.267,1.243-3.026,3.459c1.24,2.216,4.603,4.262,7.519,4.57l3.679,0.386l8.166,11.05 c-13.823,1.315-13.823,2.139-13.823,4.371c0,18.331-2.343,22.556-2.832,23.369L0,164.443v19.019l2.248,2.89 c-0.088,2.775,0.823,5.323,2.674,7.431c5.981,6.804,19.713,7.001,21.256,7.001c4.634,0,14.211-2.366,20.78-4.153 c-0.456-0.781-0.927-1.553-1.3-2.392c-0.36-0.809-0.603-1.668-0.885-2.517c-0.811-2.485-1.362-5.096-1.362-7.845 c0-14.074,11.449-25.516,25.515-25.516s25.52,11.446,25.52,25.521c0,6.068-2.221,11.578-5.773,15.964 c-0.753,0.927-1.527,1.828-2.397,2.641c-1.022,0.958-2.089,1.859-3.254,2.641c29.332,0.109,112.164,0.514,168.708,1.771 c-0.828-0.823-1.533-1.771-2.237-2.703c-0.652-0.854-1.222-1.75-1.761-2.688c-2.164-3.744-3.5-8.025-3.5-12.655 c0-14.069,11.454-25.513,25.518-25.513c14.064,0,25.518,11.449,25.518,25.513c0,5.126-1.553,9.875-4.152,13.878 c-0.605,0.922-1.326,1.755-2.04,2.594c-0.782,0.922-1.616,1.781-2.527,2.584c5.209,0.155,9.699,0.232,13.546,0.232 c19.563,0,23.385-1.688,23.861-5.018C324.114,202.108,324.472,199.602,317.833,197.111z"></path> <path d="M52.17,195.175c3.638,5.379,9.794,8.922,16.756,8.922c0.228,0,0.44-0.062,0.663-0.073c2.576-0.083,5.043-0.61,7.291-1.574 c1.574-0.678,2.996-1.6,4.332-2.636c4.782-3.702,7.927-9.429,7.927-15.933c0-11.144-9.066-20.216-20.212-20.216 s-20.213,9.072-20.213,20.216c0,2.263,0.461,4.411,1.149,6.446c0.288,0.85,0.616,1.673,1.015,2.471 C51.279,193.606,51.667,194.434,52.17,195.175z"></path> <path d="M269.755,209.068c2.656,0,5.173-0.549,7.503-1.481c1.589-0.642,3.06-1.491,4.422-2.495 c1.035-0.767,1.988-1.616,2.863-2.559c3.34-3.604,5.432-8.389,5.432-13.681c0-11.144-9.071-20.21-20.215-20.21 s-20.216,9.066-20.216,20.21c0,4.878,1.812,9.3,4.702,12.801c0.818,0.989,1.719,1.89,2.708,2.713 c1.311,1.088,2.729,2.024,4.293,2.755C263.836,208.333,266.704,209.068,269.755,209.068z"></path> </g> </g> </g></svg>
                                </span>
                                <span class="vehicle-label">Car</span>
                            </span>
                        </label>
                     </div>
                </div>
            </div>
            </form>
        </div>
    </div>
    <footer>
        <div class="footer">
            <button id="staffSlotManagement"><i class="fa-solid fa-house"></i></button>
            <button id="staffSlotOverview"><i class="fa-solid fa-car"></i></button>
            <button><i class="fa-solid fa-circle-info"></i></button>
            <button id="snippetButton"><i class="fa-solid fa-user"></i></button>
        </div>
    </footer>
</div>

<!-- Include the right sidebar -->
<?php include '../components/sidebarRight.php'; ?>


<?php include '../components/viewSlotModal.php'; ?>
<?php include '../components/editSlotModal.php'; ?>
<?php include '../components/checkoutModal.php'; ?>
<?php include '../components/addSlotModal.php'; ?>

</section>

<?php include '../components/profileSnippet.php'; ?>
<?php include '../components/profileModal.php'; ?>
<?php include '../components/editProfileModal.php'; ?>
<?php include '../components/passwordModal.php'; ?>

<script>
    const urlParams = new URLSearchParams(window.location.search);
if (
  urlParams.has("add_slot") ||
  urlParams.has("edit_slot") ||
  urlParams.has("checkout_slot") ||
  urlParams.has("user_edit") ||
  urlParams.has("password_changed")
) {
  document.getElementById("loader-container").style.display = "none";

  // Disable the header immediately
  document.querySelector("header").classList.add("disabled");

  // Disable all elements with the class "cards"
  document.querySelectorAll(".cards").forEach((card) => {
    card.classList.add("disabled");
  });

  // Disable other specified elements
  document.querySelector(".reserved-list-container").classList.add("disabled");
  document.querySelector(".sidebar").classList.add("disabled");
  document.querySelector(".table-container").classList.add("disabled");
  document.querySelector(".filter-container").classList.add("disabled");
}

</script>

     <script>
      document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("staffSlotManagement").onclick = function () {
            location.href = "staffSlotManagement.php";
        }
        document.getElementById("staffSlotOverview").onclick = function () {
          location.href = "StaffSlotOverview.php";
        }
      });
     </script>

    <script>
        document.querySelector('.parking-table').addEventListener('click', function (event) {

            if (event.target.closest('.view-btn')) {
                const button = event.target.closest('.view-btn'); 
                const selectedZone = button.getAttribute('data-zone');
                const selectedSlot = button.getAttribute('data-slot-number');
                const selectedFloor = button.getAttribute('data-floor');
                const plateNumber = button.getAttribute('data-plate-number');
                const userType = button.getAttribute('data-user-type');
                const vehicleType = button.getAttribute('data-vehicle-type');
                const status = button.getAttribute('data-status');
                const timeIn = button.getAttribute('data-time-in');

                document.getElementById('modal-floor').textContent = selectedFloor;
                document.getElementById('modal-zone').textContent = selectedZone;
                document.getElementById('modal-slot').textContent = selectedSlot;
                document.getElementById('modal-license-plate').textContent = plateNumber;
                document.getElementById('modal-user-type').textContent = userType;
                document.getElementById('modal-vehicle-type').textContent = vehicleType;
                document.getElementById('modal-status').textContent = status;

                document.getElementById('hidden-time-in').value = timeIn;

                // Handle time_in: if it's 'null', empty, or invalid, hide the field
                const modalTimeIn = document.getElementById('modal-time-in');
                const modalTimeInField = document.getElementById('modal-time-in-field');

                if (timeIn && timeIn !== 'null' && timeIn.trim() !== '') {
                    const date = new Date(timeIn);
                    const formattedDate = date.toLocaleString('en-US', { 
                        year: 'numeric', 
                        month: '2-digit', 
                        day: '2-digit', 
                        hour: '2-digit', 
                        minute: '2-digit', 
                        hour12: true 
                    });
                    modalTimeIn.textContent = formattedDate;
                    modalTimeInField.style.display = 'block'; 
                } else {
                    modalTimeInField.style.display = 'none'; 
                }

                // Display vehicle type Image
                const vehicleImageContainer = document.querySelector('.view-vehicle-type');
                vehicleImageContainer.innerHTML = ''; 

                let imgSrc = '';

                // Match vehicle type and set corresponding image
                if (vehicleType === 'Car') {
                    imgSrc = '../img/Cars.svg';
                } else if (vehicleType === 'Motorcycle') {
                    imgSrc = '../img/Moto.svg';
                } else if (vehicleType === 'Bicycle') {
                    imgSrc = '../img/Bikes.svg';
                } else {
                    imgSrc = '../img/Parking.svg'; 
                }

                const vehicleImg = document.createElement('img');
                vehicleImg.src = imgSrc;
                vehicleImg.alt = vehicleType;
                vehicleImageContainer.appendChild(vehicleImg);

                $('#slotModal').modal('show');
            }
        });
    </script>

    <script>
    $('#search, input[name="floors[]"], input[name="zones[]"], input[name="vehicle_types[]"]').on('input change', function() {
        var searchQuery = $('#search').val();
        var selectedFloors = $('input[name="floors[]"]:checked').map(function() {
            return $(this).val();
        }).get(); 
        var selectedZones = $('input[name="zones[]"]:checked').map(function() {
            return $(this).val();
        }).get(); 
        var selectedVehicleTypes = $("input[name='vehicle_types[]']:checked").map(function() {
            return $(this).val();
        }).get();

        $.ajax({
            url: '../php/parkingExecute.php',
            type: 'GET',
            data: { search: searchQuery, 
                    floors: selectedFloors, 
                    zones: selectedZones, 
                    vehicle_types: selectedVehicleTypes },
            success: function(data) {
                $('.parking-table tbody').html(data);
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    });
    </script>

    <script>
    const ResetFilter = document.getElementById("resetFilter");
    const searchFilter = document.getElementById('search');
    const filterFloor = document.querySelectorAll("input[name='floors[]']");
    const filterZone = document.querySelectorAll("input[name='zones[]']");
    const filterVehicle = document.querySelectorAll("input[name='vehicle_types[]']");

    ResetFilter.addEventListener('click', function() {
        filterFloor.forEach(function(checkbox) {
            checkbox.checked = false;
        });

        filterZone.forEach(function(checkbox) {
            checkbox.checked = false;
        });

        filterVehicle.forEach(function(checkbox) {
            checkbox.checked = false;
        });

        searchFilter.value = '';
        resetTable();
    });

    // Function to reset the table data
    function resetTable() {
        var searchQuery = '';

        console.log('Sending AJAX request to reset table...');

        $.ajax({
            url: '../php/parkingExecute.php',
            type: 'GET',
            data: { 
                search: searchQuery, 
                floors: [],
                zones: [],
                vehicle_types: []
            },
            success: function(data) {
                console.log('AJAX request successful, updating table...');
                $('.parking-table tbody').html(data);
            },
            error: function(xhr, status, error) {
                console.error('AJAX request failed:', error);
            }
        });
    }
    </script>

    
     <script src="../js/modal.js"></script>
     <script src="../js/loading.js"></script>
     <script src="../js/section.js"></script>


     <?php include '../php/alerts.php'; ?>
</body>
</html>
